/* Home preview uses the same pure model with a fresh fixed scenario. */
(function(){
var slider=document.getElementById('apValue');if(!slider)return;
var sel=GL_SCORE_INPUTS.defaultSelection.map(function(i){return GL_SCORE_INPUTS.items[i]});
function rows(r){return r.map(function(x,i){return '<div class="ap-row'+(i===0?' first':'')+'"><span class="ap-rank">'+(i+1)+'</span><div><div class="ap-name">'+glEscape(x.p.name)+'</div><div class="ap-brand">'+x.p.mass+' g · $'+x.price.toFixed(2)+' reference</div></div><div class="ap-score">'+x.total.toFixed(2)+'<small> /10</small></div></div>'}).join('')}
function render(){var r=glRank(sel,[5,+slider.value],glOptions()),gap=r[0].total-r[1].total;document.getElementById('apRows').innerHTML=rows(r);document.getElementById('apValueOut').textContent=slider.value+' / 10';document.getElementById('apNote').textContent='Conditional mass–price preference only. Top-two gap '+gap.toFixed(2)+'/10. '+(gap<0.3?'Within':'Outside')+' the editor-set approximate tie range (<0.3); not a statistical error margin. Personal fit is unverified for every candidate. Reference prices are not live offers.';}
var hero=document.getElementById('heroScoreRows');if(hero)hero.innerHTML=rows(glRank(sel,[5,5],glOptions()));
slider.addEventListener('input',render);render();
})();
