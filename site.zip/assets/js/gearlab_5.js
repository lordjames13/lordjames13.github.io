
/* View router — one view at a time: Home / Products / Compare / Case Studies / Strategy Lab / About.
   Internal view keys and section ids keep their original names (catalog, research, …)
   so every existing hash link (#catalog, #research, section anchors) keeps working.
   P3-4 — Case Studies is an index plus one article at a time, with stable
   routes: #case-studies (index) and #case-studies/<slug> (article). The
   pre-P3-4 anchors (#flagship, #case-cleaning, #case-charging,
   #case-kitchen, #background, #tradeoffs, …) land on the article that
   contains them and scroll to the anchor. Navigation pushes real history
   entries and hashchange/popstate re-render, so Back returns to the index. */
(function(){
function gid(id){return document.getElementById(id)}
var VIEWS={
home:[document.querySelector(".hero"),gid("selected"),gid("analysisPreview"),gid("method"),gid("homeByline")],
compare:[gid("cmpIntro"),gid("compare"),gid("advanced"),gid("weighted"),gid("method-notes")],
catalog:[gid("catalog")],
research:[gid("evidenceTaskAudit"),gid("chargingLaunchResearch"),gid("gamingHeadsetResearch"),gid("gamingKeyboardResearch"),gid("chargingAccessoryResearch"),gid("insightsIntro"),gid("csBack"),gid("csIndex"),gid("flagship"),gid("prd"),gid("tradeoffs"),gid("case-charging"),gid("case-cleaning"),gid("case-kitchen"),gid("fieldCaster"),gid("fieldRobotArm"),gid("fieldChargingSystem"),gid("background"),gid("research"),gid("spotlight"),gid("playbook"),gid("deepdive"),gid("inspiration")],
gtm:[gid("stratIntro"),gid("strategyMemos"),gid("strategyMemoBack"),gid("strategyMemoPremium"),gid("strategyMemoCleaning"),gid("strategyMemoCharging"),gid("strategyMemoMethods"),gid("gtm"),gid("simulator")],
about:[gid("about")]
};
var MAP={home:"home",top:"home",selected:"home",method:"home",homeByline:"home",analysisPreview:"home",compare:"compare",cmpIntro:"compare",advanced:"compare",weighted:"compare","method-notes":"compare",finderBox:"compare",finder:"compare",catalog:"catalog",gtm:"gtm",stratIntro:"gtm",simulator:"gtm",about:"about"};
var TITLES={home:"GearLab — An Independent Product Intelligence Lab",catalog:"Products — GearLab",compare:"Compare — GearLab",research:"Case Studies — GearLab",gtm:"Strategy Lab — GearLab",about:"About — GearLab"};
/* P3-4 — Case Studies articles: route slug → section ids shown, in order. */
var CS_ARTICLES={
"evidence-task-audit":["evidenceTaskAudit"],
"charging-launch":["chargingLaunchResearch"],
"gaming-headsets":["gamingHeadsetResearch"],
"gaming-keyboards":["gamingKeyboardResearch"],
"charging-accessories":["chargingAccessoryResearch"],
"gaming-mouse":["flagship","prd"],
"trade-offs":["tradeoffs"],
"charging":["case-charging"],
"smart-cleaning":["case-cleaning"],
"kitchen":["case-kitchen"],
"hospital-casters":["fieldCaster"],
"robot-arm-workflow":["fieldRobotArm"],
"charging-system":["fieldChargingSystem"],
"background":["background","research","spotlight","playbook","deepdive","inspiration"]
};
var CS_TITLES={"evidence-task-audit":"Can a Reader Trace the Evidence? — GearLab","charging-launch":"From 100W to a Complete Setup — GearLab","gaming-headsets":"Selling Dual Audio Without Overpromising — GearLab","gaming-keyboards":"Beyond 8K — GearLab","charging-accessories":"Build the Setup, Not a Pile of Chargers — GearLab","gaming-mouse":"Beyond the Spec Sheet: What Makes a Gaming Mouse Competitive? — GearLab","trade-offs":"Design Trade-off Explorer — GearLab","charging":"Charging & Power Case Study — GearLab","smart-cleaning":"Smart Cleaning Case Study — GearLab","kitchen":"Kitchen Appliances Case Study — GearLab","hospital-casters":"Hospital Caster — Original Field Note — GearLab","robot-arm-workflow":"Robot Arm Workflow — GearLab","charging-system":"Charging as a System — GearLab","background":"Background Research — GearLab"};
/* Pre-P3-4 anchors → the article that contains them. */
var CS_ANCHOR_ARTICLE={evidenceTaskAudit:"evidence-task-audit",chargingLaunchResearch:"charging-launch",gamingHeadsetResearch:"gaming-headsets",gamingKeyboardResearch:"gaming-keyboards",chargingAccessoryResearch:"charging-accessories",flagship:"gaming-mouse",prd:"gaming-mouse","cs-sense":"gaming-mouse","cs-analysis":"gaming-mouse","cs-business":"gaming-mouse","cs-method":"gaming-mouse",tradeoffs:"trade-offs","case-charging":"charging","case-cleaning":"smart-cleaning","case-kitchen":"kitchen",fieldCaster:"hospital-casters",fieldRobotArm:"robot-arm-workflow",fieldChargingSystem:"charging-system",background:"background",spotlight:"background",playbook:"background",deepdive:"background",inspiration:"background"};
var CS_ALL=["evidenceTaskAudit","chargingLaunchResearch","gamingHeadsetResearch","gamingKeyboardResearch","chargingAccessoryResearch","flagship","prd","tradeoffs","case-charging","case-cleaning","case-kitchen","fieldCaster","fieldRobotArm","fieldChargingSystem","background","research","spotlight","playbook","deepdive","inspiration"];
/* Phase 4: deep-linkable business memos with a lightweight Strategy Lab index. */
var ST_ARTICLES={"premium-mouse":"strategyMemoPremium","smart-cleaning":"strategyMemoCleaning","charging":"strategyMemoCharging","methodology":"strategyMemoMethods"};
var ST_TITLES={"premium-mouse":"Premium Mouse Decision Memo — GearLab","smart-cleaning":"Smart Cleaning Decision Memo — GearLab","charging":"Charging Strategy Decision Memo — GearLab","methodology":"Business Strategy Methods — GearLab"};
var stSlug=null;
function stApply(){
 var idx=!stSlug;
 ["stratIntro","strategyMemos","gtm","simulator"].forEach(function(id){var n=gid(id);if(n)n.style.display=idx?"block":"none"});
 var back=gid("strategyMemoBack");if(back)back.style.display=idx?"none":"block";
 Object.keys(ST_ARTICLES).forEach(function(slug){var n=gid(ST_ARTICLES[slug]);if(n)n.style.display=slug===stSlug?"block":"none"});
 if(stSlug)document.title=ST_TITLES[stSlug];
}

var csSlug=null; /* null = the index */
function csApply(){
var idx=!csSlug;
[["insightsIntro",idx],["csIndex",idx],["csBack",!idx]].forEach(function(p){var n=gid(p[0]);if(n)n.style.display=p[1]?"block":"none"});
CS_ALL.forEach(function(id){var n=gid(id);if(n)n.style.display=(!idx&&CS_ARTICLES[csSlug].indexOf(id)>-1)?"block":"none"});
if(csSlug&&CS_TITLES[csSlug])document.title=CS_TITLES[csSlug];
}
function show(name,anchor){
if(!VIEWS[name])name="home";
document.title=TITLES[name];
Object.keys(VIEWS).forEach(function(k){VIEWS[k].forEach(function(n){if(n)n.style.display=(k===name)?"block":"none"})});
if(name==="research")csApply();
if(name==="gtm")stApply();
document.querySelectorAll("[data-nav]").forEach(function(a){a.classList.toggle("on",a.getAttribute("data-nav")===name)});
var m=document.querySelector("main");m.classList.remove("vin");void m.offsetWidth;m.classList.add("vin");
if(anchor){var t=gid(anchor);if(t&&t.getClientRects().length){t.scrollIntoView();return}}
var h=document.documentElement,sb=h.style.scrollBehavior;h.style.scrollBehavior="auto";window.scrollTo(0,0);h.style.scrollBehavior=sb;
}
/* P3-2 — deep links into Compare: "#compare?category=cleaning" switches the
   Compare tab to that category; "&product=<name>" additionally preselects
   the product where Compare has a product selector — the weighted engine's
   mouse slots (mice is the only category with one). A bare "#compare"
   behaves exactly as before. Click handling is delegated to the document
   because Products cards are re-rendered dynamically. */
function applyCompare(params){
var cat=null,prod=null;
params.split("&").forEach(function(kv){var i=kv.indexOf("=");if(i<0)return;var k=kv.slice(0,i),val=kv.slice(i+1);try{val=decodeURIComponent(val)}catch(_){}
if(k==="category")cat=val;else if(k==="product")prod=val});
if(!cat||typeof DATA==="undefined"||!DATA[cat])return;
if(typeof render==="function")render(cat);
if(prod&&typeof cmpSelectProduct==="function")cmpSelectProduct(cat,prod);
if(prod&&cat==="mice"){
var idx=-1;DATA.mice.items.forEach(function(p,i){if(p.name===prod)idx=i});
var s=gid("wA");
if(idx>-1&&s){s.value=idx;if(typeof wDedupe==="function")wDedupe("wA");if(typeof wCalc==="function")wCalc()}
}
var t=gid("compare");if(t)t.scrollIntoView();
}
function route(){
var raw=(location.hash||"").replace(/^#/,"");
var qi=raw.indexOf("?");var base=qi>-1?raw.slice(0,qi):raw;var params=qi>-1?raw.slice(qi+1):"";
if(base==="strategy-memos"||base.indexOf("strategy-memos/")===0){
 var slug=base==="strategy-memos"?"":base.slice("strategy-memos/".length);
 stSlug=ST_ARTICLES[slug]?slug:null;
 show("gtm");
 if(!stSlug){var idx=gid("strategyMemos");if(idx)idx.scrollIntoView()}
 return true;
}
if(base==="case-studies"||base.indexOf("case-studies/")===0){
var slug=base.slice("case-studies/".length);
csSlug=CS_ARTICLES[slug]?slug:null;
show("research");return true;
}
if(base==="research"||base==="insightsIntro"){csSlug=null;show("research");return true}
if(CS_ANCHOR_ARTICLE[base]){csSlug=CS_ANCHOR_ARTICLE[base];show("research",base);return true}
if(MAP[base]){if(MAP[base]==="gtm")stSlug=null;show(MAP[base],(base in VIEWS)?null:base);if(base==="compare"&&params)applyCompare(params);return true}
return false;
}
document.addEventListener("click",function(e){
var a=e.target&&e.target.closest?e.target.closest("[data-nav]"):null;
if(!a)return;
e.preventDefault();
var v=a.getAttribute("data-nav");var href=a.getAttribute("href")||"";
var frag=(href.charAt(0)==="#"&&href.length>1)?href.slice(1):"";
var qi=frag.indexOf("?");var base=qi>-1?frag.slice(0,qi):frag;var params=qi>-1?frag.slice(qi+1):"";
var target;
if(v==="research"){
if(base.indexOf("case-studies")===0)target=frag;
else if(CS_ANCHOR_ARTICLE[base])target=base;
else target="case-studies";
}else{
target=(v==="gtm"&&base.indexOf("strategy-memos")===0)?frag:(base==="method-notes"?"method-notes":(params?frag:v));
}
try{history.pushState(null,"","#"+target)}catch(_){}
route();
/* Same-view section anchors (e.g. #selected, #weighted, #simulator) keep
   the written hash at the view route, so scroll to the section directly. */
if(base&&base!==v&&base!==target){var t=gid(base);if(t&&t.getClientRects().length)t.scrollIntoView()}
});
window.addEventListener("hashchange",function(){route()});
window.addEventListener("popstate",function(){route()});
if(!route())show("home");
})();
