/* Category research: hypothetical DTC pilot, never live manufacturer economics.
   Definitions and Python reproduction: resources/code/charging_launch_inputs.json
   and reproduce_charging_launch.py. No analytics or customer data is collected. */
(function () {
  'use strict';
  var ids = ['chargingCvr', 'chargingAttach', 'chargingCableStock', 'chargingFallback'];
  var controls = ids.map(function (id) { return document.getElementById(id); });
  var host = document.getElementById('chargingModelResult');
  if (!host || controls.some(function (el) { return !el; })) return;
  var money = new Intl.NumberFormat('en-US', {style:'currency', currency:'USD', maximumFractionDigits:0});
  var count = new Intl.NumberFormat('en-US', {maximumFractionDigits:1});
  function render() {
    var cvr = Number(controls[0].value) / 100;
    var attach = Number(controls[1].value) / 100;
    var stock = Number(controls[2].value);
    var fallback = Number(controls[3].value);
    var wanted = Math.min(10000 * cvr, 400);
    var requested = wanted * attach;
    var bundles = Math.min(requested, stock);
    var lost = (requested - bundles) * (1 - fallback);
    var single = wanted - bundles - lost;
    var contribution = single * 35 + bundles * 43 - 500;
    var delta = contribution - 10500;
    document.getElementById('chargingCvrOut').textContent = (cvr*100).toFixed(1) + '%';
    document.getElementById('chargingAttachOut').textContent = (attach*100).toFixed(0) + '%';
    document.getElementById('chargingCableStockOut').textContent = String(stock);
    host.replaceChildren();
    var big = document.createElement('strong'); big.className = 'rx-big';
    big.dataset.negative = String(delta < 0);
    big.textContent = (delta > 0 ? '+' : '') + money.format(delta);
    host.appendChild(big);
    [
      'Modeled incremental contribution vs the control, after the $500 pilot setup cost.',
      count.format(bundles) + ' fulfilled bundles + ' + count.format(single) + ' standalone orders; ' + count.format(lost) + ' modeled lost orders.',
      money.format(contribution) + ' pilot contribution vs ' + money.format(10500) + ' control contribution.',
      'Unmet bundle requests: ' + count.format(Math.max(0,requested-bundles)) + '. ' + (requested>stock ? 'Cable availability is constraining the offer.' : 'Cable stock covers modeled bundle requests.')
    ].forEach(function (text) {var p=document.createElement('p');p.textContent=text;host.appendChild(p);});
  }
  controls.forEach(function (el) {el.addEventListener(el.tagName==='SELECT'?'change':'input', render);});
  render();
})();
