/* Generated snapshot of resources/code/GearLab_Comparator_Model_Inputs.json. */
var GL_SCORE_INPUTS = {
  "schemaVersion": 2,
  "title": "GearLab conditional mass–price preference model",
  "checked": "2026-11-14",
  "scope": "Manufacturer-reported inputs plus explicit preference assumptions. No measured comfort, aim performance, reliability, or overall product quality score. Reference prices mix list/observed/launch benchmarks and are NOT comparable live offers. Override with your own same-date, same-region pre-tax quotes before a purchase comparison.",
  "criteria": [
    "mass",
    "price"
  ],
  "weights": [
    5,
    5
  ],
  "anchors": {
    "mass": [
      40,
      80
    ],
    "price": [
      50,
      200
    ]
  },
  "nearTie": 0.3,
  "defaultSelection": [
    0,
    1,
    2
  ],
  "items": [
    {
      "id": "harpe2",
      "name": "ROG Harpe II Ace",
      "variant": "Standard Black/White; manufacturer approximate mass, cable excluded",
      "mass": 48,
      "price": 169.99,
      "priceBasis": "US reference list price shown alongside a $114.99 promotion; benchmark uses $169.99, not the sale.",
      "priceDate": "2026-11-14",
      "dimensions": "126.1 × 63.9 × 39.7 mm",
      "bluetooth": true,
      "source": "https://rog.asus.com/us/mice-mouse-pads/mice/wireless/rog-harpe-ii-ace/spec/",
      "reason": "~48 g is the manufacturer claim. At the illustrative 40–80 g anchors it maps to 8.00/10. No personal comfort inference follows from mass or dimensions."
    },
    {
      "id": "superlight2",
      "name": "G PRO X SUPERLIGHT 2",
      "variant": "Standard White; not DEX, SE or SUPERSTRIKE",
      "mass": 60,
      "price": 159.99,
      "priceBasis": "US manufacturer listed price observed on the selected White model; not a live quote.",
      "priceDate": "2026-11-14",
      "dimensions": "125 × 63.5 × 40 mm",
      "bluetooth": false,
      "source": "https://www.logitechg.com/en-us/shop/p/pro-x2-superlight-wireless-mouse",
      "reason": "60 g is the manufacturer claim. At the illustrative 40–80 g anchors it maps to 5.00/10. Pro adoption is not converted into reliability or comfort points."
    },
    {
      "id": "viper3",
      "name": "Viper V3 Pro",
      "variant": "Standard Black RZ01-05120100-R3U1; White is 55 g and not this record",
      "mass": 54,
      "price": 159.99,
      "priceBasis": "US launch MSRP from manufacturer announcement, 23 Apr 2024; retained reference benchmark, not a verified current offer.",
      "priceDate": "2024-04-23",
      "dimensions": "127 × 64 × 40 mm",
      "bluetooth": false,
      "source": "https://www.razer.com/gaming-mice/razer-viper-v3-pro",
      "priceSource": "https://www.razer.com/newsroom/product-news/reshaping-esports-dominance-introducing-the-razer-viper-v3-pro-the-mouse-of-champions",
      "reason": "54 g applies to Black only. At the illustrative 40–80 g anchors it maps to 6.50/10. Optical switch design does not establish measured lifetime reliability."
    },
    {
      "id": "atlantis",
      "name": "Atlantis OG V2 4K",
      "variant": "Exact edition, included receiver and US price basis pending",
      "mass": null,
      "price": null,
      "dimensions": "Not reverified",
      "bluetooth": null,
      "source": null,
      "reason": "Withheld from scoring: original approximate mass and channel price were not backed by an exact-variant source record. Unknown is not zero."
    },
    {
      "id": "dragonfly",
      "name": "Dragonfly F1 Pro Max",
      "variant": "Pro Max only; do not substitute F1 Pro specifications",
      "mass": null,
      "price": null,
      "dimensions": "Not reverified",
      "bluetooth": null,
      "source": null,
      "reason": "Withheld from scoring: the original record mixed F1 series variants. No sensor, mass or price assumptions are used to fill missing fields."
    },
    {
      "id": "a7",
      "name": "A7 Ultra",
      "variant": "Exact edition and sales region pending",
      "mass": null,
      "price": null,
      "dimensions": "Not reverified",
      "bluetooth": null,
      "source": null,
      "reason": "Withheld from scoring: a 42–48 g range across variants cannot stand in for a documented single-model mass. Price basis also unverified."
    }
  ]
};

/* Retired inputs: structural audit only, never live scoring. */
var GL_RETIRED_AUDIT = {
  "status": "RETIRED — structural audit only; these ratings are unvalidated editorial inputs, not product evidence. Never used in the live comparator.",
  "criteria": [
    "light",
    "comfort",
    "value",
    "trust",
    "grip",
    "hand"
  ],
  "weights": [
    6,
    6,
    5,
    5,
    7,
    5
  ],
  "selection": [
    0,
    1,
    3
  ],
  "items": [
    {
      "name": "ROG Harpe II Ace",
      "light": 10,
      "comfort": 6,
      "value": 6,
      "trust": 7,
      "fit": {
        "claw": 10,
        "fingertip": 10,
        "palm": 4
      },
      "hand": {
        "s": 9,
        "m": 9,
        "l": 5
      }
    },
    {
      "name": "G PRO X SUPERLIGHT 2",
      "light": 6,
      "comfort": 10,
      "value": 6,
      "trust": 10,
      "fit": {
        "claw": 8,
        "fingertip": 6,
        "palm": 9
      },
      "hand": {
        "s": 6,
        "m": 10,
        "l": 9
      }
    },
    {
      "name": "Viper V3 Pro",
      "light": 8,
      "comfort": 8,
      "value": 7,
      "trust": 9,
      "fit": {
        "claw": 10,
        "fingertip": 8,
        "palm": 6
      },
      "hand": {
        "s": 7,
        "m": 10,
        "l": 8
      }
    },
    {
      "name": "Atlantis OG V2 4K",
      "light": 8,
      "comfort": 8,
      "value": 8,
      "trust": 5,
      "fit": {
        "claw": 10,
        "fingertip": 7,
        "palm": 7
      },
      "hand": {
        "s": 7,
        "m": 10,
        "l": 8
      }
    },
    {
      "name": "Dragonfly F1 Pro Max",
      "light": 10,
      "comfort": 6,
      "value": 10,
      "trust": 4,
      "fit": {
        "claw": 9,
        "fingertip": 9,
        "palm": 4
      },
      "hand": {
        "s": 9,
        "m": 8,
        "l": 5
      }
    },
    {
      "name": "A7 Ultra",
      "light": 10,
      "comfort": 5,
      "value": 10,
      "trust": 3,
      "fit": {
        "claw": 9,
        "fingertip": 9,
        "palm": 4
      },
      "hand": {
        "s": 9,
        "m": 8,
        "l": 4
      }
    }
  ]
};
