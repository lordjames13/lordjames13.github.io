/* Generated from resources/code/commercial_model_inputs.json and business_metric_contract.json. */
var BIZ_MODEL_CONFIG = {
  "version": 2,
  "title": "Strategy Lab — explicitly hypothetical order economics",
  "checked": "2026-11-14",
  "scope": "One model period, USD, one item per placed order, up to one attributed placed order per paid click. Expected counts may be fractional. These assumptions are not actual demand, platform reporting definitions, customer acquisition or causal lift.",
  "default": {
    "price": 165,
    "budget": 20000,
    "cpc": 1.2,
    "ctr": 0.018,
    "cvr": 0.025,
    "pc": 70,
    "fc": 12,
    "rc": 8,
    "refund": 0.05,
    "fixed": 1000
  },
  "presets": {
    "low": {
      "label": "Lower-price illustration",
      "inputs": {
        "price": 99,
        "budget": 20000,
        "cpc": 0.85,
        "ctr": 0.024,
        "cvr": 0.032,
        "pc": 52,
        "fc": 10,
        "rc": 9,
        "refund": 0.05,
        "fixed": 1000
      }
    },
    "premium": {
      "label": "Premium-price illustration",
      "inputs": {
        "price": 185,
        "budget": 25000,
        "cpc": 1.45,
        "ctr": 0.016,
        "cvr": 0.028,
        "pc": 78,
        "fc": 14,
        "rc": 7,
        "refund": 0.06,
        "fixed": 1500
      }
    }
  },
  "fields": [
    {
      "key": "price",
      "id": "dsPrice",
      "label": "Booked AOV, USD",
      "format": "money",
      "min": 0,
      "step": 1,
      "definition": "After discounts, before refunds; exclude sales tax and pass-through taxes. A modeling input, not a manufacturer price."
    },
    {
      "key": "cvr",
      "id": "dsCvr",
      "label": "Simulated placed orders per paid click, %",
      "format": "percent",
      "min": 0,
      "max": 100,
      "step": 0.1,
      "definition": "Assumes at most one placed order per click. This is neither unique-visitor CVR nor new-customer conversion."
    },
    {
      "key": "pc",
      "id": "dsPc",
      "label": "Product cost net of recoveries / placed order, USD",
      "format": "money",
      "min": 0,
      "step": 0.5,
      "definition": "Expected product/landed cost after any recovered returned inventory value, averaged across all placed orders."
    },
    {
      "key": "fc",
      "id": "dsFc",
      "label": "Fulfilment and channel cost / placed order, USD",
      "format": "money",
      "min": 0,
      "step": 0.5,
      "definition": "Expected shipping, payment and channel fees, net of fee reversals; same placed-order denominator."
    },
    {
      "key": "rc",
      "id": "dsRc",
      "label": "Return handling, warranty and support / placed order, USD",
      "format": "money",
      "min": 0,
      "step": 0.5,
      "definition": "Expected handling/logistics and service expense. Excludes refund principal and product recoveries counted elsewhere."
    },
    {
      "key": "refund",
      "id": "dsRefund",
      "label": "Refund allowance, % of booked revenue",
      "format": "percent",
      "min": 0,
      "max": 100,
      "step": 0.5,
      "definition": "Expected refunded value divided by booked revenue, including partial refunds. It is not the percentage of orders returned."
    },
    {
      "key": "budget",
      "id": "dsBudget",
      "label": "Media spend in model period, USD",
      "format": "money",
      "min": 0,
      "step": 500,
      "definition": "Fully spent media budget; no extra organic volume is assumed. Actual CPC response to scaling is unknown."
    },
    {
      "key": "cpc",
      "id": "dsCpc",
      "label": "Average CPC, USD / paid click",
      "format": "money",
      "min": 0.01,
      "step": 0.05,
      "definition": "Positive average paid-click price. No measured auction curve or traffic constraint is supplied."
    },
    {
      "key": "ctr",
      "id": "dsCtr",
      "label": "CTR, clicks / impressions, %",
      "format": "percent",
      "min": 0,
      "max": 100,
      "step": 0.1,
      "definition": "Only back-calculates impressions in this fixed-spend, fixed-CPC model. Positive clicks with zero CTR are inconsistent."
    },
    {
      "key": "fixed",
      "id": "dsFixed",
      "label": "Incremental fixed campaign/content cost, USD",
      "format": "money",
      "min": 0,
      "step": 100,
      "definition": "Charge once to this model period. No company-wide overhead, financing, income tax or lifetime value is modeled."
    }
  ],
  "stressCases": [
    {
      "key": "downside",
      "label": "Downside stress",
      "factors": {
        "cvr": 0.7,
        "cpc": 1.25,
        "rc": 1.5,
        "refund": 1.5
      }
    },
    {
      "key": "base",
      "label": "As entered",
      "factors": {}
    },
    {
      "key": "upside",
      "label": "Upside stress",
      "factors": {
        "cvr": 1.3,
        "cpc": 0.85,
        "rc": 0.8,
        "refund": 0.8
      }
    }
  ],
  "assumptionProvenance": {
    "source": "Editorial constructed examples",
    "observedBaseline": null,
    "targetApproved": false,
    "campaignExecuted": false,
    "meaning": "Neither preset is a market benchmark, ASUS economics, a treatment effect or an approved target. Refunds and fixed campaign costs were added in v2; legacy exhibits use a different aggregate allowance."
  }
};
var BIZ_METRIC_CONTRACT = {
  "version": 1,
  "checked": "2026-11-14",
  "status": "Proposed measurement contract. No observed campaign, customer, returns or industry benchmark data were supplied.",
  "metrics": [
    {
      "key": "incremental_contribution",
      "label": "Incremental contribution / assigned eligible visitor",
      "numerator": "Arm net sales minus variable costs, attributable media and fixed intervention cost allocated once under a preregistered period rule; take treatment minus control per assigned visitor.",
      "denominator": "All eligible unique visitors assigned to each arm, including non-buyers; stable assignment and one specified follow-up horizon.",
      "unit": "USD / assigned visitor; absolute treatment-control difference",
      "proposedDataSource": "Order/refund/finance ledger + randomisation log + documented cost allocation; not platform ROAS.",
      "cohortWindow": "After attribution, refunds and cost reconciliation mature; pilot enrolment duration is not the outcome follow-up window.",
      "decisionRole": "Primary experiment outcome; hurdle and precision must be approved before launch.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "visitor_conversion",
      "label": "Unique-visitor purchase conversion",
      "numerator": "Assigned eligible visitors placing at least one qualifying paid order within the predefined conversion window; each buyer counts once. Later refunds remain separate outcomes and are not silently removed from this numerator.",
      "denominator": "All eligible unique visitors assigned to that arm. Do not substitute sessions, clicks or units.",
      "unit": "Proportion; report both relative change and percentage-point difference",
      "proposedDataSource": "Stable assignment/eligibility log linked to de-duplicated orders; consent and cross-device limitations documented.",
      "cohortWindow": "Lock assignment date, conversion window, timezone and invalid-traffic rules before starting.",
      "decisionRole": "Secondary diagnostic; lower funnel conversion alone does not establish profit.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "ad_purchase_rate",
      "label": "Platform orders / ad click",
      "numerator": "Purchases credited to the specified ad report, attribution model, promoted-SKU or brand scope, and click/view basis.",
      "denominator": "Paid clicks in that exact report/cohort. A repeat purchase is not necessarily a new buyer.",
      "unit": "Orders / click; need not be a unique-person probability",
      "proposedDataSource": "Native ad export and its current metric definitions/report metadata. Do not sum overlapping exports.",
      "cohortWindow": "Record window and reporting-date basis from the actual report; mature it before comparison. No universal 14-day assumption.",
      "decisionRole": "Acquisition diagnostic; different from unique-visitor CVR and causal incrementality.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "fit_return_rate",
      "label": "Confirmed fit-coded return incidence",
      "numerator": "Unique delivered qualifying orders with a completed fit-coded return requested inside the predefined post-delivery return window; multiple reasons count the order once.",
      "denominator": "All delivered qualifying orders in the same mature delivery-date cohort, including orders never returned.",
      "unit": "Proportion; relative reduction and percentage-point change",
      "proposedDataSource": "Delivery/order/return records, fixed coding rubric, reviewed ambiguous/missing reason counts.",
      "cohortWindow": "Delivery date starts follow-up; require the full chosen return horizon plus processing lag for every included order.",
      "decisionRole": "Customer-experience guardrail or separate outcome. With uncoded returns this is a confirmed lower-bound rate, not fully identified actual fit-return incidence; compare coding coverage and show bounds.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "fit_reason_share",
      "label": "Fit share among coded returns",
      "numerator": "Fit-coded returned orders using the same coding rubric.",
      "denominator": "Returned orders with an assessed reason; separately report missing/uncoded reasons.",
      "unit": "Share among returns; not return incidence",
      "proposedDataSource": "Coded returns log with reason coverage and consistency checks.",
      "cohortWindow": "Same mature order cohort and reason coding as incidence.",
      "decisionRole": "Diagnostic only: the share can fall while total returns rise.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "roas",
      "label": "Attributed ROAS / ACOS",
      "numerator": "ROAS numerator = attributed sales on an explicitly stated gross-booked or refund-adjusted basis; ACOS numerator = media spend.",
      "denominator": "ROAS denominator = media spend; ACOS denominator = that same sales value.",
      "unit": "ROAS ratio; ACOS proportion; reciprocals only on the same non-zero basis",
      "proposedDataSource": "Ad export reconciled to finance; show platform sales scope and any refund adjustment separately.",
      "cohortWindow": "Same currency, attribution scope, date basis, window and maturity.",
      "decisionRole": "Efficiency diagnostic. No universal 3.0 threshold; break-even depends on margin and fixed costs.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "media_cpa",
      "label": "Media cost / attributed placed order",
      "numerator": "Media spend on the exact same report basis.",
      "denominator": "Attributed placed orders, not customers; zero orders means undefined cost/order, not $0.",
      "unit": "USD / attributed placed order",
      "proposedDataSource": "Ad spend and report orders; de-duplicate cross-channel credit before a blended total.",
      "cohortWindow": "Same attributed cohort/window as the purchases.",
      "decisionRole": "Called CPA/cost per order here; not customer acquisition cost.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "true_cac",
      "label": "New-customer CAC",
      "numerator": "Acquisition expenditure using a documented included-cost rule.",
      "denominator": "Distinct newly acquired customers under a specified existing-customer lookback; cancelled/refunded customer rules stated.",
      "unit": "USD / new customer",
      "proposedDataSource": "Customer identity/history + finance + deduplicated new-customer attribution.",
      "cohortWindow": "State lookback and observation horizon; do not infer from orders or a vendor label alone.",
      "decisionRole": "Not available in this portfolio; simulator does not estimate true CAC.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "bundle_attach",
      "label": "Bundle choice / accessory attach",
      "numerator": "For bundle choice: eligible completed orders choosing the bundle; for accessory attach: qualifying accessory units/orders with the base product, as separately defined.",
      "denominator": "Bundle choice: all eligible completed base-or-bundle orders. Accessory attach needs its own declared eligible base-order denominator.",
      "unit": "Conditional share; not visitor conversion or incremental demand",
      "proposedDataSource": "SKU/order lines, bundle eligibility and stock logs; avoid counting bundled components twice.",
      "cohortWindow": "Same availability window and completed-order definition; report stockouts separately.",
      "decisionRole": "Secondary diagnostic; purchase conditioning and standalone accessory cannibalisation can mislead.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "visibility",
      "label": "Organic top-three query-observation share",
      "numerator": "Predeclared query/device/location/time observations with an organic result in positions 1–3. Paid placements are separate.",
      "denominator": "All eligible observations in that planned audit, with unavailable observations recorded.",
      "unit": "Share of audited observations, not market share",
      "proposedDataSource": "Search audit with query set, geographic/device settings, schedule and placement classification.",
      "cohortWindow": "Use a fixed sampling protocol and comparable audit dates.",
      "decisionRole": "Visibility diagnostic; no top-three promise and no assumed causal sales effect.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    },
    {
      "key": "comprehension",
      "label": "Feature/routing comprehension",
      "numerator": "Participants answering a preregistered question correctly.",
      "denominator": "Participants answering that question; show invited/assigned counts and missing responses separately.",
      "unit": "Diagnostic proportion with response coverage",
      "proposedDataSource": "Versioned questionnaire and assignment log; do not manufacture a pass threshold after seeing results.",
      "cohortWindow": "Same question, exposure and assessment window.",
      "decisionRole": "Early UX diagnostic; not purchase conversion or commercial success.",
      "observedBaseline": null,
      "approvedTarget": null,
      "owner": "To be assigned before a real pilot"
    }
  ],
  "targetPolicy": {
    "observedBaseline": null,
    "flagshipMedian": null,
    "approvedTarget": null,
    "currentDecision": "Not ready for an outcome claim or spend-scale decision",
    "oldClaimsWithdrawn": [
      "Amazon conversion >= flagship median +15%",
      "Fit-related returns down 20% in 90 days",
      "Own top-three search slots",
      "Universal ROAS target 3.0",
      "Three TikTok posts per week as a validated growth requirement"
    ],
    "toyConversion": {
      "baselineBuyers": 200,
      "baselineEligibleVisitors": 10000,
      "comparisonBuyers": 230,
      "comparisonEligibleVisitors": 10000,
      "relativeChange": 0.15,
      "percentagePointChange": 0.3,
      "status": "Invented arithmetic illustration; not an observed baseline or target"
    },
    "toyReturns": {
      "baselineFitReturns": 100,
      "baselineMatureDeliveredOrders": 2000,
      "comparisonFitReturns": 80,
      "comparisonMatureDeliveredOrders": 2000,
      "relativeReduction": 0.2,
      "percentagePointChange": -1,
      "status": "Invented arithmetic illustration; not observed return incidence or an approved target"
    },
    "economicHurdleExample": {
      "eligibleVisitors": 10000,
      "incrementalFixedCostUsd": 500,
      "contributionPerExtraOrderUsd": 40,
      "minimumConversionDifference": 0.00125,
      "percentagePointDifference": 0.125,
      "assumedBaselineConversion": 0.02,
      "relativeDifference": 0.0625,
      "status": "Invented economic break-even illustration with all other costs/traffic fixed; not an approved target, statistical MDE or observed baseline."
    }
  },
  "planning": {
    "enrolmentDaysExample": 90,
    "status": "Illustrative planning envelope, not a commitment to statistical power or outcome maturity",
    "requiredBeforeExperiment": [
      "Specified estimand and eligible population",
      "Metric version, denominator and observation windows",
      "Observed baseline / uncertainty and data quality",
      "Business-relevant MDE, sample-size/precision plan and analysis rule",
      "Stable randomisation and sample-ratio checks",
      "Comparable price, promotions, shipping, stock and traffic mix",
      "Predefined guardrails, spend cap and stopping rule",
      "Attribution, return and finance maturity plus deduplication",
      "Named decision and finance owners; target approval"
    ]
  },
  "sources": [
    {
      "id": "B1",
      "title": "Amazon Attribution official guide",
      "url": "https://advertising.amazon.com/library/guides/basics-of-amazon-attribution",
      "use": "Distinguish reporting scope and attribution; no company baseline supplied."
    },
    {
      "id": "B2",
      "title": "GA4 dimensions and metrics",
      "url": "https://support.google.com/analytics/table/13948007?hl=en",
      "use": "Session/user/event denominators differ; not interchangeable CVR measures."
    },
    {
      "id": "B3",
      "title": "Kohavi and Longbotham (2023), Online Controlled Experiments and A/B Tests",
      "url": "https://exp-platform.com/Documents/2023-03-11EncyclopeiaMLDSABTestingFinal.pdf",
      "use": "Randomised experimentation and validity checks; the GearLab trial remains unrun."
    }
  ]
};
