
/* P3-3 — the weighted engine and preference finder live inside the collapsed
   Advanced Analysis disclosure. Any navigation aimed at them (hash links
   from Home, Case Studies, or a direct #weighted / #finderBox URL) opens
   the disclosure first, in the capture phase, before the router scrolls. */
(function(){
function openAdv(){var d=document.getElementById("advDetails");if(d)d.open=true}
document.addEventListener("click",function(e){
var a=e.target&&e.target.closest?e.target.closest("a"):null;if(!a)return;
var h=a.getAttribute("href")||"";
if(h==="#weighted"||h==="#finderBox")openAdv();
},true);
var h=(location.hash||"").replace("#","").split("?")[0];
if(h==="weighted"||h==="finderBox")openAdv();
})();
