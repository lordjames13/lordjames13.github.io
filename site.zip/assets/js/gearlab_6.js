
/* H4: retire the one-time hero load fade shortly after first paint, so
   navigating away and back to Home never replays it. */
setTimeout(function(){document.body.classList.add("hero-done")},700);
