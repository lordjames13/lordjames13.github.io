/* GearLab research expansion. Accessory facts are manufacturer snapshots, not lab results.
   Canonical accessory records live here; catalog and comparison reuse the same objects. */
var GL_ACCESSORIES = [
  {
    "name": "Prime Charger 100W (A2688)",
    "brand": "Anker",
    "origin": "cn",
    "kind": "wall",
    "badge": "100W / 3 ports",
    "code": "A2688",
    "source": "anker100",
    "fact": "Two USB-C ports and one USB-A port; the manufacturer lists 100W maximum with two ports in use and 89W with three.",
    "question": "Does plugging in a third device change the laptop charging experience?",
    "good": "A useful case for showing the difference between headline wattage and the active-port budget.",
    "bad": "The 100W label is not a promise of 100W from the laptop port in every configuration.",
    "specs": [
      "100W rated; 89W maximum with 3 ports",
      "2× USB-C + 1× USB-A",
      "2 ports: 100W total; 3 ports: 89W total",
      "Manufacturer protection claims; not independently tested",
      "No battery",
      "43.5 × 29 × 67.8 mm; 170 g",
      "See manufacturer; price not tracked"
    ]
  },
  {
    "name": "Nexode Pro 100W (15202)",
    "brand": "UGREEN",
    "origin": "cn",
    "kind": "wall",
    "badge": "100W / PD + PPS",
    "code": "15202",
    "source": "ugreen100",
    "fact": "A 100W wall charger with two USB-C ports and one USB-A port. The U.S. specification sheet lists PD and PPS on its USB-C ports.",
    "question": "Does the required phone charging protocol work on the specific port being used?",
    "good": "Port-level protocol information supports a more useful compatibility check.",
    "bad": "The checked specification table does not establish every simultaneous port allocation.",
    "specs": [
      "100W total; USB-C1 up to 100W alone",
      "2× USB-C + 1× USB-A; PD / PPS",
      "Full simultaneous allocation not verified in this review",
      "Manufacturer protection claims; not independently tested",
      "No battery",
      "71 × 43 × 33 mm; mass not rechecked",
      "See manufacturer; price not tracked"
    ]
  },
  {
    "name": "240W Braided USB-C Cable (3/6/10 ft)",
    "brand": "Anker",
    "origin": "cn",
    "kind": "cable",
    "badge": "240W / USB 2.0",
    "code": "240W",
    "source": "ankercable",
    "fact": "The support page rates this cable family for up to 240W charging but only 480Mbps USB 2.0 data.",
    "question": "Is this cable for charging, or also for a monitor and fast external storage?",
    "good": "A clear example of why charging power and data rate need separate labels.",
    "bad": "Do not infer USB4 or monitor capability from a 240W power rating. Select the exact cable length and variant.",
    "specs": [
      "Up to 240W cable rating; not a power source",
      "USB-C to USB-C; USB 2.0 at 480Mbps",
      "Negotiated power depends on charger and device",
      "Certification database entry not independently checked",
      "No battery",
      "3 / 6 / 10 ft family; select exact length",
      "See manufacturer; price not tracked"
    ]
  },
  {
    "name": "USB4 80Gbps Cable (201305)",
    "brand": "Cable Matters",
    "origin": "us",
    "kind": "cable",
    "badge": "80Gbps / 240W",
    "code": "USB4",
    "source": "cablematters",
    "fact": "Product 201305 is manufacturer-listed for up to 80Gbps USB4 data and 240W PD 3.1 EPR charging, with supported video dependent on both endpoints.",
    "question": "Can the host, dock and display use the cable capabilities being purchased?",
    "good": "Power, data and video capabilities are stated separately.",
    "bad": "A cable cannot upgrade a slower host port or guarantee a particular monitor mode.",
    "specs": [
      "Up to 240W cable rating; not a power source",
      "USB4 up to 80Gbps; USB-C to USB-C",
      "Requires compatible source, sink and negotiated mode",
      "USB-IF certification claimed by manufacturer; listing not independently audited",
      "No battery",
      "Select the exact length on the source page",
      "See manufacturer; price not tracked"
    ]
  },
  {
    "name": "MagGo 3-in-1 Pad (A25M1)",
    "brand": "Anker",
    "origin": "cn",
    "kind": "wireless",
    "badge": "Phone + watch + earbuds",
    "code": "3-in-1",
    "source": "maggo3",
    "fact": "The A25M1 manual specifies Qi2 phone charging up to 15W, plus 5W for AirPods and 5W for Apple Watch; a 40W PD adapter and cable are listed as included.",
    "question": "Does one travel kit cover the actual phone, watch and earbud combination?",
    "good": "The included adapter and cable make bundle completeness visible.",
    "bad": "Compatibility must be checked for each device; adding the three output ratings is not a measured wall-power result.",
    "specs": [
      "Phone up to 15W; earbuds 5W; watch 5W",
      "Qi2 pad plus dedicated watch / earbud charging positions",
      "Included 40W PD adapter; per-device output ratings",
      "No original thermal or long-session test",
      "No battery",
      "Foldable pad; dimensions not rechecked",
      "See manufacturer; price not tracked"
    ]
  },
  {
    "name": "BoostCharge Pro Qi2 Pad (WIZ021)",
    "brand": "Belkin",
    "origin": "us",
    "kind": "wireless",
    "badge": "15W Qi2 / 30W adapter",
    "code": "Qi2",
    "source": "belkin",
    "fact": "The WIZ021 pad lists up to 15W Qi2 phone charging, a 5W earbud pad and a 5W USB-C output; a 30W power supply and cable are included.",
    "question": "Is the additional USB-C output sufficient for the accessory the buyer expects to attach?",
    "good": "The extra wired output is a concrete bundle distinction.",
    "bad": "The extra USB-C output is rated 5W; it is not a laptop-charging port.",
    "specs": [
      "Phone up to 15W; earbuds 5W; USB-C output 5W",
      "Qi2 phone pad + earbud pad + USB-C output",
      "Included 30W power supply",
      "Manufacturer-listed Qi2; no independent heat test",
      "No battery",
      "82 × 163 × 15 mm",
      "See manufacturer; price not tracked"
    ]
  },
  {
    "name": "MagGo Power Bank 10K (A1654)",
    "brand": "Anker",
    "origin": "cn",
    "kind": "bank",
    "badge": "10,000mAh / 38.5Wh",
    "code": "10K",
    "source": "maggo10",
    "fact": "A1654 is rated at 10,000mAh / 38.5Wh, with wireless output up to 15W and USB-C output up to 27W.",
    "question": "What usable energy and carrying burden does magnetic convenience add?",
    "good": "A stated Wh rating allows energy accounting without confusing cell mAh with delivered phone capacity.",
    "bad": "Delivered energy and wireless efficiency were not measured; the 10,000mAh label is not usable output at every voltage.",
    "specs": [
      "Wireless up to 15W; USB-C up to 27W",
      "Qi2 wireless + 1× USB-C",
      "Simultaneous wired / wireless allocation not verified",
      "Manufacturer protection claims; not independently tested",
      "10,000mAh; 38.5Wh rated",
      "107.3 × 68.8 × 19.8 mm",
      "See manufacturer; price not tracked"
    ]
  },
  {
    "name": "TS4 Thunderbolt Dock",
    "brand": "CalDigit",
    "origin": "us",
    "kind": "dock",
    "badge": "18 ports / 98W host",
    "code": "TS4",
    "source": "ts4",
    "fact": "The TS4 lists 18 connections and host charging up to 98W. The front USB-C power port is rated 20W, distinct from the host port.",
    "question": "Does the dock support the actual laptop, display topology and charging load?",
    "good": "Charging and desk connectivity can be evaluated as one workflow.",
    "bad": "98W host power is not the rating of every USB-C port. Display support depends on the host.",
    "specs": [
      "Up to 98W host charging",
      "Thunderbolt 4 / USB4; 18 connections",
      "Host 98W; front USB-C 20W; downstream TB ports 15W each",
      "Use the specified external power supply",
      "No battery",
      "141 × 42 × 113 mm; 0.64 kg",
      "See manufacturer; price not tracked"
    ]
  }
];
var GL_RESEARCH_SOURCES = {
  "razer": [
    "Razer: BlackShark V2 Pro (2023) launch and feature details",
    "https://www.razer.com/newsroom/product-news/introducing-the-2023-razer-blackshark-v2-pro-the-definitive-esports-headset-evolves"
  ],
  "razerfaq": [
    "Razer: BlackShark V2 Pro (2023), RZ04-0453 support",
    "https://mysupport.razer.com/app/answers/detail/a_id/13060"
  ],
  "delta": [
    "ASUS: ROG Delta II, U.S. product page",
    "https://rog.asus.com/us/headsets-audio/headsets/wireless-headsets/rog-delta-ii/"
  ],
  "hyperx": [
    "HyperX: Cloud III Wireless, original model",
    "https://hyperx.com/products/hyperx-cloud-iii-wireless-gaming-headset"
  ],
  "wooting": [
    "Wooting: original 80HE",
    "https://wooting.io/wooting-80he?Color=Black"
  ],
  "polling": [
    "Wooting: scanning and USB polling explained",
    "https://wooting.io/post/wooting-80he-the-true-polling-rate"
  ],
  "hfx": [
    "ASUS: ROG Falchion Ace HFX",
    "https://rog.asus.com/us/keyboards/keyboards/compact/rog-falchion-ace-hfx/"
  ],
  "usb": [
    "USB-IF: cable capabilities and certification requirements",
    "https://www.usb.org/cable_connector"
  ],
  "anker100": [
    "Anker Prime 100W, three ports, A2688",
    "https://www.anker.com/products/a2688-anker-prime-charger-100w-3-ports-gan"
  ],
  "ugreen100": [
    "UGREEN Nexode Pro 100W, three ports, SKU 15202",
    "https://us.ugreen.com/products/ugreen-nexode-pro-100w-gan-fast-charger"
  ],
  "ankercable": [
    "Anker: braided 240W USB-C cable, 3/6/10 ft family",
    "https://service.anker.com/article-description/Introduction-to-Anker-240W-USB-C-to-USB-C-Cable-3-ft-6-ft-10-ft-240W-Braided"
  ],
  "cablematters": [
    "Cable Matters: USB4 80Gbps cable, product 201305",
    "https://www.cablematters.com/pc-1760-124-usb-if-certified-80gbps-usb4-cable-thunderbolt-54-compatible.aspx"
  ],
  "maggo3": [
    "Anker: MagGo three-in-one pad, A25M1 manual",
    "https://service.anker.com/product-description/a08J1000000YcHWIA0?recordId=a08J1000000YcHWIA0"
  ],
  "belkin": [
    "Belkin: Qi2 two-in-one pad, WIZ021",
    "https://www.belkin.com/p/2-in-1-magnetic-wireless-charging-pad-with-qi2-15w/P-WIZ021.html"
  ],
  "maggo10": [
    "Anker: MagGo 10K power bank, A1654",
    "https://www.anker.com/products/a1654-maggo-10000mah-qi2-power-bank-magsafe-compatible"
  ],
  "ts4": [
    "CalDigit: TS4, U.S. specifications",
    "https://us.caldigit.com/products/ts4"
  ]
};
(function(){
GL_ACCESSORIES.forEach(function(p){
 var s=GL_RESEARCH_SOURCES[p.source];
 DATA.charging.items.push({name:p.name,brand:p.brand,tag:[p.origin==='us'?'us':'cn',p.kind],price:'See source',priceLabel:'price not tracked',src:s[1],srct:s[0],checked:'14 Nov 2026',specs:p.specs,good:[p.good],bad:[p.bad],verdict:p.question,lesson:'Editorial hypothesis: '+p.good,fit:{},hand:{}});
});
DATA.charging.note='Manufacturer snapshots checked 14 Nov 2026 for the eight added accessories; the three original entries retain their earlier snapshot. Chargers, cables, pads, power banks and docks have different jobs. Compare capabilities within a form factor; this mixed set has no common performance ranking. Rated watts do not guarantee a device-specific charging rate.';
var planner={
 comms:{title:'Measure whether the message gets through',focus:'Use the same callouts, microphone position and chat application. Have blinded listeners score word recognition with and without defined background noise.',metric:'Word recognition, repeat requests, and processing settings.',limit:'A bigger microphone or a marketing bandwidth claim does not establish better intelligibility.'},
 mixing:{title:'Measure recovery between audio sources',focus:'Separate switching from simultaneous playback. Test the actual game, phone call and voice-chat combination, including the return to team audio.',metric:'Recovery time, missed callouts, and incorrect audio-source selections.',limit:'Two supported wireless connections do not automatically mean two sources can be mixed.'},
 session:{title:'Measure interruptions and fit over time',focus:'Keep volume and connection mode consistent. Record charging interruptions and pressure / heat reports at fixed checkpoints, including glasses use.',metric:'Interrupted sessions, mode settings, and repeated comfort reports.',limit:'Manufacturer battery hours and product mass do not independently measure long-session comfort.'}
};
var task=document.getElementById('rxHeadsetTask'),result=document.getElementById('rxHeadsetResult');
function plan(){var p=planner[task.value];result.replaceChildren();var h=document.createElement('h3');h.textContent=p.title;result.appendChild(h);[p.focus,'Proposed measures: '+p.metric,'Boundary: '+p.limit].forEach(function(t){var n=document.createElement('p');n.textContent=t;result.appendChild(n)})}
if(task&&result){task.addEventListener('change',plan);plan();}
var polling=document.getElementById('rxPolling'),actuation=document.getElementById('rxActuation');
function inputTiming(){document.getElementById('rxInterval').textContent=(1000/Number(polling.value)).toFixed(3).replace(/0+$/,'').replace(/\.$/,'')+' ms';var depth=Number(actuation.value);document.getElementById('rxActuationOut').textContent=depth.toFixed(1)+' mm';document.getElementById('rxActuationNote').textContent=depth.toFixed(1)+' mm is the illustrated initial press threshold. '+(depth<1?'A shallow threshold is worth testing for unintended presses.':depth>=2.5?'A deeper threshold is worth testing for effort and missed inputs.':'Test this starting point in both play and writing tasks.')+' Rapid Trigger reset behavior and total latency are separate.'}
if(polling&&actuation){polling.addEventListener('change',inputTiming);actuation.addEventListener('input',inputTiming);inputTiming();}
document.querySelectorAll('[data-rx-filter]').forEach(function(button){button.addEventListener('click',function(){var kind=button.dataset.rxFilter,n=0;document.querySelectorAll('[data-rx-filter]').forEach(function(b){b.setAttribute('aria-pressed',String(b===button))});document.querySelectorAll('[data-rx-kind]').forEach(function(card){card.hidden=kind!=='all'&&card.dataset.rxKind!==kind;if(!card.hidden)n++});document.getElementById('rxAccessoryCount').textContent=n+(n===1?' accessory':' accessories')+' · '+(kind==='all'?'5 types':button.textContent)})});
var ids=['rxBudget','rxCable','rxLaptop','rxPhone','rxOther'];
function budget(){var values=ids.map(function(id){return Number(document.getElementById(id).value)}),total=values[0],cable=values[1],laptop=values[2],phone=values[3],other=values[4],remaining=Math.max(0,total-phone-other),allocation=Math.min(laptop,remaining,cable);['Laptop','Phone','Other'].forEach(function(k,i){document.getElementById('rx'+k+'Out').textContent=values[i+2]+'W'});var host=document.getElementById('rxPowerResult');host.replaceChildren();var b=document.createElement('strong');b.className='rx-big';b.textContent=allocation+'W';host.appendChild(b);var p=document.createElement('p');p.textContent='Illustrative laptop allocation · '+total+'W budget − '+phone+'W phone − '+other+'W other = '+remaining+'W remaining, capped by a '+cable+'W cable rating and '+laptop+'W laptop request.';host.appendChild(p);var note=document.createElement('p');note.textContent=(phone+other>total?'The other-device demand already exceeds the total budget. ':allocation<laptop?'The requested laptop power is not met in this simplified scenario. ':'The request fits the arithmetic budget. ')+'Actual compatibility and port behavior still need verification.';host.appendChild(note)}
ids.forEach(function(id){document.getElementById(id).addEventListener(id==='rxBudget'||id==='rxCable'?'change':'input',budget)});budget();
})();
