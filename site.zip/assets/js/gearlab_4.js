
/* Design Trade-off Explorer — scenario switcher (Insights). All product figures are the verified
   Compare data (manufacturer listings, checked Nov 2026). Observations are limited to published
   product photos and spec tables; no hands-on testing is claimed anywhere in this module. */
(function(){
var EV={spec:"Manufacturer Specs",ext:"External Research",obs:"My Observation",hyp:"Unverified Hypothesis",claim:"Manufacturer mechanism claim — not a reliability test"};
function tag(k){return '<span class="ev ev-'+(k==="claim"?"spec":k)+'">'+EV[k]+'</span>'}
var SCEN={
fps:{
need:{t:"Land every flick exactly once — no re-gripping mid-fight, no misclicks, no attention spared for the hardware. At this level the mouse is not a tool the player operates; it is a variable they need to eliminate, so consistency of aim outranks every other quality.",ev:"ext"},
attrs:[
["Weight","First-order here: less mass means less inertia to start and stop on a flick. The verified spread in this tier is narrow but real — Harpe II Ace 48 g, Viper V3 Pro 54 g, SUPERLIGHT 2 60 g.","spec"],
["Shape","Decides whether the grip survives speed. The Viper's listed best fit is claw · fingertip; the SUPERLIGHT 2's is palm-claw · claw. Same price, different hands — the same player is not equally served by both shells.","spec"],
["Grip compatibility","Grip is the interface, not a preference toggle: fingertip players steer with their fingers and need a short, low shell; claw players need rear support for the knuckles. A shape rated for your grip removes the micro-adjustments that break aim mid-fight.","ext"],
["Connectivity","2.4 GHz dongle or nothing. The Viper polls at up to 8,000 Hz with the dongle included in the box; Bluetooth's polling ceiling rules it out for ranked play — so the Viper's missing Bluetooth costs nothing in this scenario.","spec"],
["Button placement","In the published product photos, the Viper's side buttons sit high on the left flank, clear of the thumb's resting zone — reachable for abilities without loosening the grip that is doing the aiming.","obs"],
["Battery life","Rated up to 95 h at 1K polling — a weekly charge, not a daily ritual. But the rating is at 1K: no 8,000 Hz battery figure appears in the verified Compare data, so endurance at maximum polling stays an open number, not a claim.","spec"],
["Material","The material question at this level is coating grip under damp hands. Published long-term reviews of flagship coatings consistently judge grip-when-sweaty, not dry texture, as the differentiator.","ext"]],
trades:[
["Lighter vs. battery and structure: the 48 g Harpe rates ≈90 h against the Viper's 95 h at 1K — the last grams are bought with battery capacity and shell thickness.","spec"],
["Universal shape vs. grip-specific fit: the SUPERLIGHT 2's safer palm-claw shell fits the most hands and fully commits to none; the Harpe's narrow, low shell is the opposite bet — better for claw and fingertip, worse for everyone else.","spec"],
["Maximum polling vs. endurance: 8,000 Hz is a setting paid for in battery, and the size of that payment is exactly what the published specs do not state.","hyp"]],
shift:"Against Everyday Work, battery and all-day comfort fall down the list — the desk is fixed and charging is trivial. Against Portable Use, Bluetooth flips from decisive to irrelevant: here, only the dongle matters.",
assume:[
"That most ranked players can actually feel 48 g vs. 54 g once the shape fits — review culture may be overweighting the scale.",
"That 8,000 Hz polling changes match outcomes only on high-refresh setups (240 Hz and above); below that it may be pure battery cost.",
"Whether an optical actuation design changes unintended-input or failure rates over a defined ownership period; no durability advantage is assumed here."],
check:"A counterbalanced fit-and-aim panel: the same ranked players run standardised aim tasks and full matches on all three flagships, logging performance, grip shifts and comfort across 90-minute sessions — so the weight and shape claims above meet evidence.",
plan:{
recruit:"12–16 ranked FPS players (top ~10% of their ladder or equivalent), deliberately mixed across hand sizes and claw / fingertip / palm grips, because every trade-off here is grip-dependent.",
tasks:"Each player runs the same aim-trainer battery (flick, tracking, target-switching) plus two full matches per mouse, order counterbalanced, sensitivity converted to cm/360 so only the hardware changes.",
metrics:"Aim-task scores; misclick and grip-shift counts from session video; comfort and fatigue ratings at 30 / 60 / 90 minutes; an end-of-day forced ranking with reasons.",
criteria:"A mouse wins a grip group only if it leads on both performance and 90-minute comfort — a spec lead alone (lightest, highest polling) does not count. If 48 g vs. 54 g shows no measurable performance gap within a grip group, the weight-first reading gets revised.",
next:"Publish the protocol and aggregate results, then feed the findings into Compare's fit and comfort sub-scores — replacing editorial estimates with observed ones, relabelled as such."}},
work:{
need:{t:"Get through an eight-hour day without the hardware asking for attention: no hand fatigue by mid-afternoon, no dongle swaps between laptop and desktop, no battery warning during a call. The need is not performance headroom — it is the absence of friction, repeated daily.",ev:"ext"},
attrs:[
["Shape","The ranking flips. All-day work rewards palm support and a fuller hump; the Viper's listed best fit is claw · fingertip — a gaming posture. In this trio, the SUPERLIGHT 2's palm-claw rating is the better starting point for a relaxed work grip.","spec"],
["Grip compatibility","Most office users default to a relaxed palm grip and never chose it. A shell designed around claw assumes a posture work users do not hold — fit here means matching the grip people actually use, not the one a product page recommends.","ext"],
["Battery life","Charging is a chore you notice monthly or resent weekly. Up to 95 h (Viper, at 1K) and ≈90 h (Harpe) both clear the bar comfortably; what matters is that the rating holds at real-world settings.","spec"],
["Connectivity","This is where the reference mouse loses. The Viper is HyperSpeed + USB-C with no Bluetooth — one dongle, one machine. The Harpe's tri-mode (2.4 GHz · Bluetooth · USB-C) hops between laptop and desktop without moving any hardware.","spec"],
["Button placement","Side buttons earn their keep as browser back / forward. What the verified spec lists do not show for any of the three flagships is a tilt-scroll or free-spin wheel — the productivity feature this user group would feel every day.","obs"],
["Weight","Close to irrelevant. Ergonomics guidance for office pointing centres on posture and fit rather than grams; at office cursor speeds, the 48–60 g spread across this trio is not the variable driving comfort.","ext"],
["Material","Razer describes light-based actuation in its <a href='https://www.razer.com/technology/razer-optical-mouse-switch' target='_blank' rel='noopener'>switch mechanism documentation</a>. A switching principle does not establish zero unintended double inputs or zero failures. GearLab has no matched failure-rate or lifetime test; long-term reliability remains unverified.","claim"]],
trades:[
["Gaming shape vs. all-day support: the low, narrow shells that win FPS comparisons are the same ones that leave a relaxed palm unsupported at hour six.","ext"],
["Flagship sensor vs. price: a 35K sensor and 8,000 Hz polling are invisible in a spreadsheet. The $159.99 buys gaming headroom this user never opens — the honest work recommendation may be a cheaper mouse, stated as such.","spec"],
["Multi-device breadth vs. peak performance: tri-mode flexibility (Harpe) and dongle performance (Viper) are bought with the same bill of materials — no flagship here maximises both.","spec"]],
shift:"Against Competitive FPS, weight drops from first-order to cosmetic and Bluetooth jumps from irrelevant to decisive. Against Portable Use, hour-six comfort beats bag size — this mouse never travels.",
assume:[
"That office users, given the choice, would trade 8K polling and sensor headroom for Bluetooth multi-device switching at the same price.",
"That fit — not battery or buttons — is the leading reason gaming mice get returned or abandoned by work users.",
"That sub-55 g mice read as 'flimsy' to non-gamers at equal build quality, and that the perception affects satisfaction."],
check:"A two-week diary study: desk workers alternate the Viper and a palm-claw alternative in their real work, logging end-of-day comfort and every moment the mouse annoyed them, with the reason attached.",
plan:{
recruit:"10–12 full-time desk workers who use a mouse 6+ hours a day and do not own a gaming mouse — the point is to test outside the enthusiast bubble that writes most reviews.",
tasks:"Two weeks of normal work per mouse, order counterbalanced: documents, spreadsheets, browsing — plus one laptop ↔ desktop switching day per week to expose connectivity friction.",
metrics:"End-of-day comfort score (0–10); a friction log — every battery, pairing or fit annoyance, timestamped with its cause; a final keep-one choice with reasons.",
criteria:"The work recommendation changes only if one mouse wins the keep-one choice by at least 2:1 AND leads median end-of-day comfort by ≥1 point. A tie converts the published advice to 'decide on price and connectivity' — said plainly.",
next:"If connectivity friction dominates the logs, add a dedicated multi-device test to this explorer. If comfort dominates, add a true palm-shape mouse to the Compare set and re-run the panel."}},
travel:{
need:{t:"A mouse that survives the bag and disappears into the trip: it pairs with whatever laptop is open, charges from whatever cable is at hand, tracks on a café table, and never becomes the thing that got left in the hotel room. Reliability under improvisation is the whole job.",ev:"ext"},
attrs:[
["Connectivity","Decisive — and it eliminates the reference mouse. The Viper has no Bluetooth, so away from its dongle it is a wired mouse tethered to a port. The Harpe's tri-mode including Bluetooth pairs with a bare laptop and sacrifices nothing.","spec"],
["Battery life","Rated up to 95 h (Viper) and ≈90 h (Harpe) at 1K polling — weeks of travel days per charge. USB-C charging means the laptop's cable is also the mouse's cable; one less thing to pack.","spec"],
["Shape & size","Measured against a sleeve, not a desk: all three flagships run 122–127 mm long on manufacturer dimensions, so the 'travel' pick here is the least-bulky flagship — none of them is a true travel mouse, and this module will not pretend otherwise.","spec"],
["Weight","48–60 g is nothing in a bag; the lightest shell stops mattering. What replaces it is whether thin ultralight walls survive being crushed under a laptop — a property no spec sheet rates.","hyp"],
["Material","Bag abrasion, not desk wear: shells and coatings ride against zips, cables and chargers. Published durability coverage concentrates on clicks and coatings in desk use, so travel wear is the open question for all three.","ext"],
["Button placement","In the published product photos, all three keep their side buttons standing proud of the shell — easy for a thumb to find, and a plausible route to accidental clicks and wake-ups inside a packed sleeve.","obs"]],
trades:[
["Flagship size vs. sleeve space: 127 mm of mouse is a real allocation in a one-bag setup; the category's own answer — mini travel mice — sacrifices exactly the shape quality these flagships sell.","spec"],
["Dongle performance vs. dongle risk: 2.4 GHz is the better connection and the easier one to lose at an airport. Bluetooth is slightly worse on paper and impossible to leave behind in a hotel room.","ext"],
["Lightest shell vs. bag durability: the grams saved by thin walls are the same grams that would have absorbed the drop onto the café floor.","hyp"]],
shift:"Against Competitive FPS, sensor and polling fall off the list entirely. Against Everyday Work, surviving transport and pairing with anything outrank hour-six palm support.",
assume:[
"That travellers forced to pick one mouse for a trip would choose Bluetooth at 60 g over 48 g with no Bluetooth.",
"That ultralight shells fail or crack in bags at a rate users would care about — there is no published field data either way.",
"That flagship sensors track acceptably on café tables and hotel desks without a pad; published sensor figures are measured in controlled conditions."],
check:"A travel-kit field test: the same users run each flagship through a real trip week — sleeve carry, café tables, one mid-week laptop swap — logging pairing friction, surface failures and any damage against packing-day photos.",
plan:{
recruit:"8–10 frequent travellers (2+ trips a month) who work from laptops and currently carry — or pointedly refuse to carry — a mouse.",
tasks:"One real trip week per mouse: daily sleeve or bag carry, work sessions on at least three non-desk surfaces (café table, hotel desk, tray table), and one mid-week laptop swap.",
metrics:"Pairing and connection friction events; tracking failures by surface (of those attempted); end-of-trip condition checked against packing-day photos; a closing 'would you pack it again' verdict.",
criteria:"A mouse earns the portable recommendation only with zero connection failures, tracking success on ≥90% of attempted surfaces, and a pack-again yes from ≥70% of travellers. A spec advantage never overrides a field failure.",
next:"If both flagships fail the pack-again test, add a true travel mouse to the Compare set and re-run — the explorer's portable conclusion would become 'none of the above,' published as such."}}
};
var panel=document.getElementById("tdePanel");
function render(key){
var s=SCEN[key];if(!s)return;
var h='<h3>The underlying need</h3><p>'+s.need.t+' '+tag(s.need.ev)+'</p>';
h+='<h3>What matters, and why</h3>';
s.attrs.forEach(function(a){h+='<div class="tde-attr"><b>'+a[0]+'</b><span>'+a[1]+' '+tag(a[2])+'</span></div>'});
h+='<h3>The core trade-offs</h3><ul>';
s.trades.forEach(function(t){h+='<li>'+t[0]+' '+tag(t[1])+'</li>'});
h+='</ul><div class="tde-shift"><b>How the priorities shift:</b> '+s.shift+'</div>';
h+='<h3>Assumptions that still need evidence</h3><ul>';
s.assume.forEach(function(a){h+='<li>'+a+' '+tag("hyp")+'</li>'});
h+='</ul><h3>How I\u2019d check</h3><p>'+s.check+'</p>';
h+='<details><summary>How I\u2019d Validate This — the full plan</summary>'
+'<div class="model-flag">Proposed validation plan — not yet conducted. No part of this plan has been run and nothing in this module reports results from it; it is the study design I would execute, with the decision rules fixed in advance.</div>'
+'<div class="tde-plan">'
+'<div><h4>Recruit &amp; scenario tasks</h4><p><b>Who:</b> '+s.plan.recruit+'</p><p style="margin-top:6px"><b>Tasks:</b> '+s.plan.tasks+'</p></div>'
+'<div><h4>Metrics</h4><p>'+s.plan.metrics+'</p></div>'
+'<div><h4>Decision criteria</h4><p>'+s.plan.criteria+'</p></div>'
+'<div><h4>Next step</h4><p>'+s.plan.next+'</p></div>'
+'</div></details>';
panel.innerHTML=h;
}
document.querySelectorAll("[data-scen]").forEach(function(b){b.addEventListener("click",function(){
document.querySelectorAll("[data-scen]").forEach(function(x){x.setAttribute("aria-selected",x===b?"true":"false")});
render(b.getAttribute("data-scen"));
})});
render("fps");
})();
