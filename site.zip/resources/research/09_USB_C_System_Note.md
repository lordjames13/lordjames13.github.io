# A Charger Is a System, Not a Wattage Number

*Why a capable USB-C charger can still create an unpredictable desk setup—and how product design can make compatibility easier to understand.*

**DESIGN NOTE 03 / CHARGING & INTERACTION DESIGN**  
**By Juewen Chen · GearLab · November 2026**  
**Evidence status:** Standards-based desk research + proposed UX design. No original charging-performance tests.

## The purchase that users think they are making

A charger advertised at 100 W or 200 W looks easy to compare: one number is bigger. But many people are not buying a power supply in isolation. They are trying to charge a laptop, a phone, and sometimes another accessory during an ordinary workday.

Whether that works depends on a chain: **the device's power profile, the charger's supported outputs, the specific port configuration, the cable's capability, and what happens when multiple devices are connected.** A headline maximum is not the same thing as guaranteed simultaneous output on every port.

USB-IF has invested in clearer certified USB-C cable power markings, including 60 W and 240 W capabilities in its certification framework. That helps at one point in the chain. It does not eliminate the need for the charger seller to explain per-port and multi-port behavior.

## My product observation: the interface is the problem

In a hardware comparison, I would distinguish at least three very different claims:

1. **Maximum single-port output:** What can the charger deliver under its specified conditions to a compatible device?
2. **Multi-port allocation:** What happens to each port when two or three devices draw power simultaneously?
3. **Validated setup:** Does the exact charger, port, cable and device combination negotiate the expected power profile without unexpected throttling or interruption?

A product page that lists only total wattage invites customers to guess. My hypothesis is that clarity about these states could create more value than another marginal increase in advertised peak power for some multi-device users.

## The design I would ship before adding another port

I would prototype a **Charging Setup Preview** directly on the product page:

- Select device types (for example, USB-C laptop + smartphone).
- Select the ports and cable capabilities that the customer intends to use.
- Show the manufacturer-documented output split and a conspicuous note when a combination has not been tested.
- Explain what changes when a third device is connected.
- Link to a simple compatibility and cable-capability guide rather than expecting customers to decode protocol names.

The interface must never promise a device-specific charging rate that has not been verified. It should distinguish *rated charger capability*, *cable certification*, and *measured charging behavior*.

## How I would evaluate it

I would recruit laptop-plus-phone users who regularly charge multiple devices. With representative, manufacturer-approved hardware in a supervised test setting, I would compare the existing product listing against the new interactive setup preview. Outcomes would include task success in selecting a suitable setup, decision time, confidence calibration, and compatibility-related errors. A follow-up study could assess support contacts or preventable returns, but the current GearLab has no such outcome data.

The engineering validation would use a documented device/charger/cable matrix and power measurement tools to compare negotiated power profiles with the published port-allocation specification. UX comprehension and electrical compliance are distinct checks: passing one does not establish the other.

## My conclusion

If I were prioritizing a charging accessory roadmap, **I would make the real multi-device configuration legible before treating a bigger wattage label as a product advantage.** The product being sold is a dependable charging setup, not simply a box with a large number on it.

That is an interface and product-data problem as much as a power-electronics problem.

---

### Evidence and limitations

- USB-IF, *Cables and Connectors / Certification Requirements*: https://usb.org/cable_connector
- USB-IF, *Compliance Updates — USB-C cable logo requirements*: https://compliance.usb.org/index.asp?Format=Standard&UpdateFile=Cables+and+Connectors&pubDate=20261005
- USB-IF, *Certified Cable Power Rating Logos*: https://www.usb.org/sites/default/files/2021-09/USB-IF_Cable%20Power%20Rating%20USB4%20Logo%20Announcement_FINAL.pdf

**No bench measurements, consumer interviews or conversion-rate tests were conducted for this note.** Design suggestions are hypotheses to validate. Draft developed with AI-assisted research and editing for author review.
