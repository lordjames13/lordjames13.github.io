# From Editorial Ratings to an Auditable Preference Model

GearLab Method Notes 01 · Revision 2 · Juewen Chen · 14 November 2026

## 1. What this model answers

Among exact-model records with documented inputs, which candidates better match an explicitly stated preference for lower mass and lower reference price? This is a conditional preference calculation. It is not an overall quality, comfort, reliability, aiming-performance or purchase-recommendation score. Other product categories remain descriptive comparisons.

The default is deliberately limited: two documented inputs, not six purportedly independent judgments. Fit is a separate screen. Untried fit stays unverified. The model is useful for exposing a trade-off, but a complete buying decision needs current comparable quotes, personal fit and other requirements.

## 2. Why the former six dimensions were retired

Old default weights were lightness 6, comfort 6, value 5, support/adoption 5, grip fit 7 and hand fit 5. The last five depended primarily on editorial judgment: 28/34 = 82.4%. Comfort, grip and hand fit together received 18/34 = 52.9%.

These three dimensions could reward the same shell geometry repeatedly. This is a conceptual overlap warning, not a measured correlation. Neither a brand name nor pro adoption establishes a 10/10 reliability score. Published dimensions do not establish a reader's comfort. The site now removes those product-level ratings from the live mouse dataset and retires the independent Finder ranking. It does not retrofit authoritative explanations onto unsupported numbers.

## 3. Exact scoring anchors

For either lower-is-preferred input x, utility = clamp(10 × (B − x) / (B − A), 0, 10), where A is the ten-point anchor and B the zero-point anchor. Between anchors the curve is linear; outside them it saturates. A and B are editable preferences, not empirically calibrated thresholds. Smaller is only preferred under this stated scenario; lower mouse mass is not universally better.

| Preference score | Mass, default grams | Price, default USD |
|---|---|---|
| 10 | 40 or less | 50 or less |
| 7.5 | 50 | 87.50 |
| 5 | 60 | 125 |
| 2.5 | 70 | 162.50 |
| 0 | 80 or more | 200 or more |

Total = (mass utility × mass weight + price utility × price weight) / (mass weight + price weight). Default weights 5/5 allocate equal value to the full 40–80 g swing and the full $50–$200 swing. They are an illustrative starting scenario, not elicited consumer preferences. Ask how much each endpoint-to-endpoint improvement matters before changing their ratio. A score of 5 is a midpoint on this preference scale, not mediocre hardware. Rounded display values never feed calculations. Anchors do not depend on which products are selected.

## 4. Model-specific evidence and reasoning

| Exact record | Manufacturer mass | Reference price | Why this is scored, and what it cannot establish |
|---|---|---|---|
| ROG Harpe II Ace, standard | approximately 48 g | $169.99 | Official US page shows this reference alongside a $114.99 promotion, checked 14 Nov 2026. Benchmark uses the reference, not promotion. Default mass utility is 8.00. Approximate manufacturer mass is not our measurement. |
| G PRO X SUPERLIGHT 2, standard White | 60 g | $159.99 | Official US selected White listing, checked 14 Nov 2026. Default mass utility is 5.00. Adoption is not translated into comfort or reliability. |
| Viper V3 Pro, standard Black | 54 g | $159.99 | Black only; White is 55 g. Price is the manufacturer's 23 Apr 2024 launch MSRP, rechecked as a historical reference, not a current offer. Default mass utility is 6.50. |
| Atlantis OG V2 4K | Unknown in revised scored dataset | Unknown | Exact edition, included receiver and consistent US price evidence pending; withheld. |
| Dragonfly F1 Pro Max | Unknown in revised scored dataset | Unknown | Original F1-series variants were mixed. Do not substitute F1 Pro mass or sensor; withheld. |
| A7 Ultra | Unknown in revised scored dataset | Unknown | Original range covered variants. Exact edition/region and price basis pending; withheld. |

The three reference prices have different commercial and temporal bases. This frozen benchmark is suitable for inspecting assumptions, not comparing today's deals. The table beside the live results exposes each basis and permits session-only user quote overrides. Use same-date, same-region pre-tax prices with equivalent necessary accessories before using price to compare an actual purchase. Entered quotes are user assumptions. Manufacturer mass, even when sourced, has tolerances and configuration dependence. No empirical mass uncertainty distribution is available here.

## 5. Fit is one screen, not three bonuses

Each model starts at “Not tried / unverified.” A reader may report pass or fail after a personal trial. Use the normal grip and settings for at least 15 minutes; inspect stable control, finger reach and pressure points. Stop if discomfort occurs. Fail if reach or control is unacceptable. Fifteen minutes is an editorial screening suggestion, not a validated duration. A short pass does not establish long-term comfort and is not independently verified by GearLab.

A reported failure excludes that candidate before scoring; lower mass or price cannot buy it back. An unknown fit is explicitly conditional, never imputed as an average or as a pass. This combined screen replaces separate comfort, grip and hand-size numeric rewards. A future study should preregister tasks and duration, recruit across hand dimensions and grips, counterbalance order, record discomfort and control separately, and report individual variability. Until then, no published personal-comfort score is warranted.

## 6. Missing information and hard requirements

All positive-weight score inputs must be finite, have an exact record and a source. Missing active information withholds the total; there is no per-product weight renormalisation and no zero imputation. Zero-weight criteria do not affect the total. A budget still needs a valid price even when price weight is zero. Bluetooth is an explicit requirement gate: unsupported candidates are excluded and unknown support is withheld. A failed fit trial also excludes. All-zero weights or reversed/equal anchors produce an explanatory no-score state.

Default anchors are utility endpoints, not hard limits. The separate optional budget field is the purchase-price cap. Completeness of two fields does not imply high-quality evidence across comfort, reliability, latency or long-term use. Evidence status and score availability are distinct.

## 7. Structural trial: reduce repeated shape weighting

For comparability, this audit freezes the old default cohort (Harpe, Logitech, Atlantis), old claw/medium settings and all old ratings. These numbers are retired, unvalidated editorial inputs, preserved only in GearLab_Retired_Scoring_Audit.json. They are not current product facts or current scores.

The merged shape score = (6 × comfort + 7 × grip + 5 × hand) / 18. Assign that group weight 6; retain lightness/value/support weights 6/5/5, total 22. This group weight is a deliberately illustrative structural alternative, not a calibrated estimate. Simply merging the group while keeping its old weight 18 would leave scores unchanged and would not address over-weighting. The removal scenario gives shape zero weight, total 16.

| Historical model | Old six dimensions | One shape group, weight 6 | Shape removed |
|---|---|---|---|
| ROG Harpe II Ace | 8.118 | 7.970 | 7.813 |
| G PRO X SUPERLIGHT 2 | 8.294 | 7.788 | 7.250 |
| Atlantis OG V2 4K | 8.265 | 7.682 | 7.063 |

The old strict leader changes from Logitech to Harpe under both alternatives. This is structural sensitivity, not evidence that Harpe is a superior product. The current two-input model changes the cohort and source basis as well, so its scores must not be interpreted as a controlled numerical before/after comparison with these retired totals. Value and support judgments remain unsupported even in the illustrative merged alternative; that is why this alternative was not adopted as the live model.

## 8. Approximate ties and sensitivity

Use “editor-set approximate tie range”: a top-two gap strictly below 0.3/10 triggers that interpretation. This range is an editorial communication choice. It is not statistical error, a confidence interval, significance or a measured minimum meaningful difference. Being outside it does not prove a better product. The old “noise band” wording is retired.

The live tool enumerates four deterministic weight corners: each of two weights is multiplied by 0.8 or 1.2 and then normalised. Zero weights stay zero. Exact ties are reported without inventing a strict winner. Counts are not probabilities. They test only those weight settings with fixed inputs and anchors; no consumer-choice probability or broad uncertainty bound follows. Edit anchors and prices to inspect other assumptions. Tests cannot validate the linear value function or a claim that 48 g is better than 60 g for a particular player.

## 9. Reproduce and inspect

The canonical current input file is resources/code/GearLab_Comparator_Model_Inputs.json. The browser snapshot in assets/js/gearlab_scoring_data.js must match it exactly. GearLab_Comparator_Reproducibility.py independently reproduces defaults, four corners and the retired structural audit; numerical tests cover missing inputs, constraints, scale endpoints, invalid weights, monotonicity and selection invariance. The browser uses the same pure functions for home and comparator, but home is explicitly a fresh reference scenario and ignores comparator overrides.

## 10. Sources and limits

- ASUS exact-model specifications and displayed US reference price: https://rog.asus.com/us/mice-mouse-pads/mice/wireless/rog-harpe-ii-ace/spec/
- Logitech exact-model US listing and mass: https://www.logitechg.com/en-us/shop/p/pro-x2-superlight-wireless-mouse
- Razer mass and color distinction: https://www.razer.com/gaming-mice/razer-viper-v3-pro
- Razer historical launch MSRP, 23 Apr 2024: https://www.razer.com/newsroom/product-news/reshaping-esports-dominance-introducing-the-razer-viper-v3-pro-the-mouse-of-champions
- UK Government, Multi-criteria analysis: a manual (2009): https://www.gov.uk/government/publications/multi-criteria-analysis-manual-for-making-government-policy
- UK Government, supplementary MCDA guidance: https://www.gov.uk/government/publications/green-book-supplementary-guidance-use-of-multi-criteria-decision-analysis

The methodological guidance informs criterion separation and the interpretation of endpoint-to-endpoint weights. GearLab has not run a stakeholder swing-weight elicitation, established preference independence, or completed a validated MCDA study; this simpler preference calculator does not claim government-method compliance. No hands-on testing, user interviews, lab measurements, failure-rate dataset or causal performance validation underlies this model. This is a self-directed, AI-assisted portfolio method, independently maintained by Juewen Chen.
