# GripFit — Modular Rear-Shell Prototype and Feasibility Plan

Juewen Chen · Independent product concept · Revised 14 November 2026

## Status and scope

Independent concept only; no prototype, engineering pass result or production approval is presented. ROG Harpe II Ace, used as a public dimensional/packaging reference; not a verified retrofit platform or an ASUS-endorsed project.

This is a proposed feasibility study, not a release PRD. No CAD/interface review, working prototype, fit panel, RF validation or certification decision is reported in this portfolio.

## Problem to investigate

Some users may prefer an alternative rear-hump geometry; neither a benefit for all large hands nor a return-rate problem is established. No return dataset, coded support records or representative user panel was supplied. The frequency, rank and cause of fit-related returns are unknown.

To study returns, define a consistent coding scheme and time window, separate support contacts from returns, record the product/SKU and shipped and returned denominators, and assess missing or multiple reasons. Public review themes are a selected sample, not an estimate of return incidence. A fit-related comment is not proof of a causal defect. A controlled outcome comparison would be needed before claiming a reduction.

## Concept variants versus the actual product

The manufacturer P723 contents list reviewed on 14 Nov 2026 lists no interchangeable rear shells. These concept variants are not represented as supplied, supported or compatible accessories. Recheck the exact SKU/region before any product-content claim.

The Standard and +Hump names refer only to proposed GearLab shape variants; the final mechanism might use a latch, captive fastener, another architecture or no interchangeable part at all. Neither a snap-on interface nor compatibility with the existing product is established. Keeping existing electronics is an investigation goal, not a conclusion.

The published P723 list includes the mouse, wireless receiver and extender, cable, grip tape, spare feet and documentation. It does not list the proposed alternate rear shells [G1]. No prototype image, concept diagram or future bundle should be captioned as the real retail contents.

## Stage gates

| Stage | Proposed work | Evidence needed to proceed |
|---|---|---|
| 0 · Need and architecture review | Define use cases and alternative approaches: a buying guide, grip tape, a different complete shell, or a modular rear section. Establish access to interface data and intended-market requirements. | A justified question and a feasible investigation path; otherwise hold or use a non-hardware alternative. |
| 1 · Non-functional shape models | Compare Standard and +Hump as independent GearLab concept labels. Randomise presentation order and record hand dimensions, grip, control, pressure and discomfort in defined tasks. | Identify a plausible fit benefit and interference risks. Shape preference alone does not establish engineering feasibility. |
| 2 · Functional engineering prototypes | Only after interface review, build candidate retention/structural designs and run the check matrix with traceable configurations and stock baselines. | Pre-agreed mechanical, electrical and RF criteria met; missing evidence remains a hold, not a pass. |
| 3 · Design and compliance review | Review production process, serviceability, tooling, cost and product-change requirements with responsible engineering and compliance personnel. | Authorised, documented decisions on changes, testing and certification path before any release commitment. |
| 4 · User and commercial validation | If prior gates pass, run a sufficiently planned counterbalanced user study, then a controlled buying-guidance or offer experiment where appropriate. | Report control/comfort variability, error rates and contribution after added cost. No claim of return reduction or attach-rate lift without outcome data. |

## Engineering check matrix — all tests proposed

| Check / responsible function | Method and record | Decision rule / current limitation |
|---|---|---|
| Mass and balance — Mechanical engineering | Measure each complete configuration on the same calibrated scale, with the same battery, feet and accessories. Record repeat measurements, centre of mass and the contribution of shell, latch and fasteners. | A net increase of no more than 3 g is an exploratory design target only. Revisit after a real baseline and material/retention concept exist; no measured mass or guaranteed total is claimed. Status: Not started. |
| Retention and latch durability — Mechanical / reliability engineering | Compare candidate latch or captive-fastener designs. Log insertion/removal and retention force, accidental release, cracks and force drift through repeated swaps and intended-environment conditioning. | Derive cycle count and loads from expected swaps and ownership exposure; agree limits before testing. Reject a concept that detaches during defined use or loses required retention. No latch design is selected. Status: Not started. |
| Stiffness and input interference — Mechanical / reliability engineering | Measure force–deflection at the palm and side contact areas. Check seam movement, squeak, permanent deformation and unintended button/scroll activation under defined squeeze and torsion loads. | Compare with a documented stock baseline. Freeze force, deflection, residual-deformation and unintended-input limits before the test; unacceptable control interference is a stop condition. Status: Not started. |
| Assembly tolerance and repeatability — Mechanical / manufacturing engineering | Build an interface/tolerance stack for mating features, ribs, latch and fasteners. Inspect representative prototypes for gaps, flushness, rattle, removal access and repeatable seating; review creep and process variation. | Document fit at planned tolerance extremes and assembly yield. Printed shape models do not prove injection-moulding capability, tooling feasibility or production yield. Status: Not started. |
| PCB, battery and sensor clearance — Mechanical + electrical engineering | Obtain authorised mechanical interface data or a qualified hardware inspection. Check PCB, antenna, battery, wiring, charging access, switch linkages, sensor/feet alignment and service access through the tolerance range. | Retaining the current PCB is a design preference, not established feasibility. PCB, firmware, housing or antenna changes may be necessary; compatibility cannot be claimed from external dimensions. Status: Blocked: internal/interface data unavailable. |
| Wireless and input-performance regression — RF + electrical / test engineering | Compare stock and each functional candidate under identical firmware, connection, receiver distance, orientation, hand posture, RF environment and charge state. Log packet/input-report loss, latency distribution, dropouts, reconnection and usable range. | Cover intended 2.4 GHz and Bluetooth configurations; use wired input as a separate reference. Define acceptable regression before testing and include shell material, wall thickness, finish and retention components in the configuration record. Status: Blocked: no functional prototype. |
| Handling, durability and usability — Mechanical / reliability + user research | Check edge finish, pinch/release access, foreseeable squeeze/drop handling, unwanted detachment and protection of internal parts. Record swap completion time and assembly errors with representative users after engineering clearance. | A swap under 10 seconds is an exploratory usability target, not a demonstrated capability. Stop evaluation for unsafe handling or exposed internal components; a short successful swap does not establish lifetime durability. Status: Not started. |
| Compliance and product-change review — Responsible manufacturer / compliance lead | Identify the exact model, FCC ID/grant, antenna and certified configurations. Give the configuration-change record and test evidence to the responsible grantee, compliance specialist and, where appropriate, an accredited lab/TCB for review of relevant markets. | No certification route is determined here. An unchanged PCB is not evidence that no further testing, filing or certification work is needed; scope depends on the actual change and applicable requirements. Status: Not assessed. |

The proposed +3 g net-mass and under-10-second swap goals are exploratory aspirations only. They are not manufacturer specifications, current prototype results or release promises. Record a complete physical baseline rather than adding an assumed 3 g to the published approximately 48 g figure. Where limits are not yet set, engineering must agree loads, cycle count, tolerance range, sample plan, environment and acceptable regression before testing; thresholds must not be chosen after seeing the results.

## Fit and commercial validation

Plan the user study around the intended effect and variability, recruit across measured hand dimensions and grip styles, counterbalance order and document tasks, settings and duration. Record stable control, reach, discomfort and assembly errors separately; do not treat a majority preference as proof of ergonomic superiority. A short trial does not establish long-term comfort. Stop if discomfort or unsafe handling occurs.

The former 70% preference, 20% fit-return reduction in 90 days and 8% accessory attach assumptions are withdrawn as product acceptance or success claims. No evidence supported those cutoffs. Set endpoints, precision, sample size and commercially meaningful decision thresholds before a later study. Track any benefit against added parts, tooling, assembly, warranty and fulfilment costs; no business improvement is assumed. A QR guide may be prototyped as standalone instructions. No Armoury Crate/Gear Link integration or manufacturer support is promised.

## Compliance boundary

No “no recertification” determination is made. The responsible manufacturer/compliance team needs the exact certified configuration, grant information, proposed design changes and relevant measurements. The eCFR describes conditional pathways for changes to certified equipment [G2]; this note assigns GripFit to none of them. Applicable RF, emissions and other product requirements must be assessed for the actual configuration and markets. An unchanged PCB alone does not settle the assessment.

## Evidence log and next deliverable

Maintain a record per prototype revision: CAD/interface version, material/process/finish, measured mass, retention configuration, firmware, sample identifiers, protocol, approved thresholds, raw results, failures, limitations, decision owner and date. The next deliverable is an architecture review and documented shape-model plan. Until those exist, the status remains concept / feasibility pending.

## Sources and evidence boundaries

- [G1] ASUS ROG Harpe II Ace exact-model specifications and P723 contents: https://rog.asus.com/us/mice-mouse-pads/mice/wireless/rog-harpe-ii-ace/spec/ — Manufacturer baseline and published contents only; no internal CAD, PCB clearance, interchangeable-shell interface or modularity validation.
- [G2] 47 CFR 2.1043 — Changes in certificated equipment, eCFR: https://www.ecfr.gov/current/title-47/section-2.1043 — General change-assessment context only; no classification or legal/compliance determination for GripFit.

Sources reviewed 14 November 2026. Manufacturer specifications are not GearLab measurements. Engineering methods in this note are proposed checks, not manufacturer-endorsed instructions or completed validation. This self-directed, AI-assisted portfolio work is independent of ASUS.
