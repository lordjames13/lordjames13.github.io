# The Robot Arm Is Not the Product. The Finished Chore Is.

*What the Roborock Saros Z70 reveals about the difference between an impressive mechanism and a dependable household workflow.*

**DESIGN NOTE 02 / CONSUMER ROBOTICS**  
**By Juewen Chen · GearLab · November 2026**  
**Evidence status:** Manufacturer specifications + independent published reviews + editorial product hypothesis. Not personally tested.

## The interesting design move

A robotic vacuum with a foldable mechanical arm is instantly memorable. The Roborock Saros Z70 has exactly that visual quality, which is why I selected it as a featured object for GearLab. But the design question I care about is different from the spectacle: **what job has the arm actually taken away from the user?**

Traditional robotic cleaners have an upstream dependency. Before the machine can clean an area, someone may need to move socks, slippers, or other clutter. The Z70 tries to make obstacle handling part of the cleaning workflow. Roborock specifies a foldable five-axis OmniGrip arm and describes supported small-object handling under a 300 g limit, dependent on setup and operating conditions. That is a real architectural shift—from navigating around some obstacles to attempting to manipulate them.

It does not yet prove that the end-to-end chore has become easier.

## The failure of feature-level thinking

A robotics demonstration can show a gripper lifting a sock once. A person buying a cleaner needs a repeatable task to finish without extra involvement. That task has several states:

**Find an item → classify it → decide it is safe to touch → grip it → move it → place it appropriately → clean the exposed area → recover if anything fails.**

Any weak transition can create a new burden. The robot may require a storage zone to be configured, fail to recognize an object, move it somewhere inconvenient, or prompt the user to intervene. Published reviews have documented real-world arm limitations even while recognizing the ambition of the design. Those are reviewer observations, not GearLab measurements.

This leads to my product hypothesis: **the most valuable performance metric is not objects gripped, but cleaning sessions completed with less total human work.**

## A better scorecard for household automation

I would structure evaluation around the job rather than the mechanism:

| Dimension | Measure I would collect | Why it matters |
|---|---|---|
| Autonomous completion | Share of scheduled sessions completed without user intervention | Direct measure of self-service |
| Correct handling | Supported objects successfully and appropriately relocated / supported objects encountered | Measures useful handling, not a demo trick |
| Error burden | Number and duration of user interventions, retries and misplacements | Failures can erase time savings |
| Net time saved | Baseline manual prep time minus setup, monitoring, troubleshooting and cleanup time | Connects robotics capability to customer value |
| Safety | Incidents, near misses and unsafe contact scenarios | Should be a gate, not a weighted bonus |
| Cleaning outcome | Coverage and cleanliness with arm enabled versus disabled | The arm should not undermine the primary job |

I would compare the Z70 operating with its arm enabled and disabled, using the same home layouts, object sets and cleaning expectations; then add a comparable non-arm model if the designs and test conditions permit. Object categories and software versions would be reported, because supported behavior can change through updates. I would preregister criteria for successful placement and record failures, not only successes.

## What I would build next

I would resist adding broader object recognition before improving exception handling. First, users should have a clear choice to skip an item, review why the robot left something untouched, and understand whether human cleanup is still needed. Second, the system should distinguish *moving an obstacle far enough to clean* from *organizing an object in the correct place*. Those are different jobs with different expectations.

A staged rollout would start with a narrow set of predictable, low-risk objects and stable placement rules, then expand only after task-completion and intervention metrics meet an agreed threshold. A visually impressive arm can win attention; predictable end-to-end behavior is what could justify a place in someone's routine.

## My conclusion

I see the Saros Z70 as an ambitious product direction, not proof that robotic arms have solved household clutter. **I would fund the workflow, not the spectacle: improve completion and recovery before expanding the number of things the arm can pick up.**

That is a different kind of product judgment from asking which robot has the most suction or the longest feature list.

---

### Evidence and limitations

- Roborock, *Saros Z70 / OmniGrip*: https://us.roborock.com/pages/roborock-saros-z70
- Roborock, *Saros Z70 Product Page and FAQ*: https://us.roborock.com/products/roborock-saros-z70
- WIRED, *Review: Roborock Saros Z70* (2025): https://www.wired.com/review/roborock-saros-z70/
- Vacuum Wars, *How to Activate and Use OmniGrip*: https://vacuumwars.com/how-to-activate-and-use-the-roborock-saros-z70-omnigrip/

**No hands-on testing, household field study, or measured time savings were performed for GearLab.** The proposed metrics and staged launch approach are a product research plan, not results. Draft developed with AI-assisted research and editing for author review.
