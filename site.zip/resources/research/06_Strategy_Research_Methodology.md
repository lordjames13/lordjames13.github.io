# GearLab Strategy Notes — From Assumption to Investment Decision

**Supplementary methodology · 13 November 2026 · Independent portfolio project**

The three GearLab decision memos are different *business problems*, not three promotional recommendations: **premium positioning** (willingness to pay and unit economics), **robot-vacuum ownership** (lifecycle cost and service strategy), and **charging clarity** (certifiable technical claims and bundle economics). Each memo has an executive decision, a counterargument, a reproducible illustrative calculation, a test plan, and explicit stop conditions.

## One decision standard for all three

1. **Define the decision and counterfactual.** State what would be done without the intervention. Keep differences between compared scenarios explicit. Never describe jointly changed hypothetical presets as a causal price experiment.
2. **Segment the job-to-be-done.** A travel power bank is not a wall charger; a desk productivity mouse is not necessarily an FPS player's best fit. Comparing unlike products may reveal distinct segments but not a universal winner.
3. **Separate observed evidence from assumptions.** Manufacturer-reported specifications and certification can be referenced; conversion, contribution, returns, willingness to pay, and customer satisfaction are **not** observed in GearLab.
4. **Model contribution, not only sales.** `Contribution after acquisition = refund-adjusted net sales − matched variable costs − media spend − incremental fixed intervention costs`, with attribution and time horizon disclosed. For randomized experiments, prefer contribution **per randomized eligible visitor** to isolate the effect of the experience.
5. **Stress-test what matters.** Change CPC, conversion, variable cost and return assumptions; calculate break-even points. Do not assign probabilities to analyst-selected scenarios.
6. **Choose a staged experiment.** Start with feasibility/UX and information quality, then randomize controlled variants if the business case warrants it. Define primary outcome and stopping conditions in advance; avoid post-hoc segment stories.
7. **Show what would falsify the recommendation.** The conclusion must be changeable by credible new evidence. A company should be willing to stop a strategy that does not improve customer value or contribution.

## Framework attribution and how each is used

| Public framework | How it informs GearLab | What GearLab has *not* done |
|---|---|---|
| HBS value stick (WTP–price–cost–WTS) | Distinguishes customer value creation from price capture | Estimated observed WTP or an optimal price |
| Contribution margin and break-even analysis | Reveals viable and nonviable model regions | Accessed audited company-level cost data |
| Strategyzer desirability–feasibility–viability tests | Turns strategic claims into checkable hypotheses | Run a company-funded pilot |
| Randomized experimentation | Separates effects of fit guidance, cost transparency and bundling | Collected observed trial outcomes |
| TCO / discounted cash flow | Makes lifecycle ownership economics explicit | Measured real lifetime ownership costs |
| USB-IF certification | Distinguishes verified compliance from a brand's marketing claim | Verified certification status of every catalog product |

## Business education and research transfer

The analytical bridge from Financial Mathematics and Epidemiology is methodological rather than credential-based: separate assumptions from observations, define the estimand, build consistent denominators, evaluate uncertainty, consider confounding, and state limitations. **Do not claim a particular course taught a particular pricing technique unless supported by the academic record.** The numerical examples were computed from openly shown assumptions and can be reproduced without proprietary data.

## Portfolio publishing standards

- Label every fabricated input **Hypothetical / Modeled** directly beside the figure. Do not describe any memo as commissioned work for ASUS, Roborock, ECOVACS, Anker, UGREEN or Baseus.
- Keep external links alive, record the date of source review, and verify product variant and country-specific claims before public launch.
- Distinguish author's personally verified observations from interpretations and untested proposed experiments.
- Explain how AI-assisted drafting and development were used, and review the final memo in the first person before attributing it.
- Where code is provided, keep a deterministic reproduction script and example input data. No simulated scenario is a forecast, market share, confidence interval or business result.

### Primary references

- Harvard Business School Online: [A Beginner's Guide to Value-Based Strategy](https://online.hbs.edu/blog/post/value-based-strategy)
- Strategyzer: [How to Test Your Idea: Start With the Most Critical Hypotheses](https://www.strategyzer.com/library/how-to-test-your-idea-start-with-the-most-critical-hypotheses)
- Harvard Business Review: [The Discipline of Business Experimentation](https://hbr.org/2014/12/the-discipline-of-business-experimentation)
- USB-IF: [USB Power Delivery](https://usb.org/usb-charger-pd), [Certified Product Search](https://www.usb.org/products)


## Commercial measurement revision — 14 November 2026

See document 16 for the current metric contract. Observed baselines, industry medians, approved targets and campaign outcomes remain unavailable. Relative change and percentage-point change must both be named; denominator, cohort, attribution and return maturity must match.

The v2 live simulator separately models refund value and return-handling expense, charges fixed campaign cost once, retains losses and undefined ratios, and reports order-based CPA rather than new-customer CAC. Older exhibits keep their own published assumptions and aggregate allowances; their outputs are not the v2 default or a common causal baseline. Reports must disclose missing/immature rows and avoid duplicated source grains. A point estimate above arithmetic break-even is not sufficient for a launch decision.
