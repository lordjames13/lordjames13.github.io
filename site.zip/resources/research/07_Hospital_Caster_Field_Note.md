# Why Were the Wheels Pointing the Wrong Way?

*An observation in a hospital, a question about caster geometry, and a reminder that good product research begins by separating what we saw from what we think it means.*

**FIELD NOTE 01 / MEDICAL HARDWARE & HUMAN FACTORS**  
**By Juewen Chen · GearLab · November 2026**  
**Evidence status:** First-person visual observation + published engineering references. No device identification, measurements, or usability testing.

## The observation that stayed with me

I was in a hospital when the wheels on a piece of equipment caught my attention. From where I stood, the front supports seemed to sweep backward, while those near the rear seemed to sweep forward. A nearby machine appeared to use a more conventional wheel arrangement.

At first I assumed the difference must serve a purpose. Then I realized I could not say what that purpose was. The two machines looked different, but I did not know their exact models, loads, brake settings, or even whether all their wheels were free to swivel. I had a visual observation—not an engineering explanation.

That distinction changed how I wanted to approach the question. Rather than asking *why would someone design the front and rear wheels in opposite directions?*, the better first question is: **was I seeing a fixed design decision, or simply the resting orientation of swivel casters?**

## Hypothesis zero: the geometry might not be fixed at all

Many caster assemblies have two axes: a wheel axle that rolls, and a vertical swivel axis around which the entire fork rotates. Their horizontal separation is called *caster offset* or *trail*. This offset is part of what allows a wheel to reorient as a cart changes direction.

The Institute of Caster and Wheel Manufacturers and caster manufacturers describe offset as a factor in maneuverability, tracking and bearing load. But from a still image, a fork facing inward or outward does not establish that the mounting has been intentionally reversed. The fork may have rotated during the equipment's last movement. A perspective view can also disguise the true position of the swivel axis.

I would therefore keep three competing explanations open:

| Explanation | What it predicts | What could falsify it |
|---|---|---|
| **H0 — Normal caster orientation** | The apparent front/rear contrast changes after a controlled push or turn. | Fork orientation remains mechanically constrained in the same arrangement. |
| **H1 — Intentional mobility configuration** | Wheel type, swivel-lock configuration, or arrangement is designed for straight-line tracking versus tight turns. | The hardware and controls are identical, and observed movement does not differ. |
| **H2 — Packaging or stability constraint** | The mounting position, base geometry, or swivel clearance is chosen to avoid collisions or support a particular equipment footprint. | No measurable geometric clearance or stability advantage appears under comparable loading. |

These are **research hypotheses**, not conclusions about the machine I saw.

## The design trade-off behind a small wheel

Once I started reading technical material, I was struck by how many jobs a medical caster performs. It must roll, steer, stop, avoid unwanted motion, tolerate cleaning, and carry loads over the surfaces in its intended environment. A wheel that turns easily around a hospital bed may still be a poor choice for a tall device that needs to remain firmly in place during use.

Some mechanisms improve one job at a cost to another:

- **Swivel offset:** More trail can change tracking and maneuverability, but it affects loads on the swivel assembly and the space needed for a full turn. Offset should not be maximized without considering load and wear.
- **Wheel configuration:** Twin-wheel casters may reduce swivel effort through differential rolling, while single-wheel solutions may offer cost and straight-line advantages in some contexts.
- **Directional versus total locks:** A directional lock helps steer along corridors; a total lock keeps both the wheel and swivel assembly from moving. They solve different problems.
- **Clearance and access:** A caster's full swivel radius, brake-pedal placement, cords, cleaning access, and staff foot clearance may matter more than the way the assembly looks in a product photograph.

For medical equipment, this is not merely styling. The FDA's human-factors guidance places the intended user, task, and use environment at the center of device usability and use-related risk assessment. That does not prove any particular caster arrangement is safe; it explains why the investigation should be framed around staff tasks and risks rather than aesthetics alone.

## What I would do as a product researcher

I would not manipulate hospital equipment or test it around patients without permission. The first stage should be documentary: identify the model and caster part number, obtain manufacturer diagrams, determine which wheels swivel or lock, and record the rated load and intended operating environment.

If a manufacturer or clinical engineering team approved a controlled evaluation, I would then compare matched equipment in a safe, unloaded test area. My proposed protocol would record:

1. **Caster behavior:** Fork direction before and after moving straight, reversing, and completing a 90° turn; whether the change is free or mechanically limited.
2. **Human effort:** Start-up force, sustained push/pull force, and turning effort using a calibrated force gauge.
3. **Maneuverability:** Time and path deviation through a standardized corridor turn, plus closest clearance to a wall or obstacle.
4. **Usability and safety:** Whether staff can recognize and operate the correct brakes; foot and cable snag risk; whether the device moves unintentionally when parked.
5. **Service implications:** Access for cleaning, wear parts, maintainability, and replacement availability.

The outcome would be a decision matrix, not a single marketing score. **Safety-critical requirements must be treated as pass/fail gates** before any weighted assessment of convenience, cost, or appearance. Engineering verification and any required manufacturer validation would still be necessary before implementing a design change.

## The product decision I would make

I would **not propose flipping the caster supports, replacing all four wheels, or declaring the unusual arrangement superior** based on my observation. I would first commission a short mobility-and-locking evaluation and ask the staff who move the equipment which maneuver is most frustrating or risky.

If the dominant problem were awkward corridor turns, I would test caster configuration and directional control. If the dominant problem were unintended movement while parked, locking behavior and clarity of controls would take priority. If the problem were cleaning or cable interference, a different housing or cable-management solution might matter more than wheel orientation.

The commercial decision follows the same logic. A more expensive caster is worth considering only if its benefits—to staff effort, incident risk, downtime, service life, or cleaning time—justify its total cost over the device's life. Without field data, I would present that as a procurement hypothesis, not a cost-saving claim.

## What this observation taught me

The interesting part of the hospital encounter was not that I found an unconventional wheel. It was that I initially wanted a clever explanation before I had enough evidence to earn one.

**My takeaway is that product sense begins with noticing a difference, but it becomes product judgment only when I can identify the actual user task, keep alternative explanations alive, and design a test that could prove my favorite explanation wrong.**

That is the approach I want to bring to medical hardware: curiosity about details, respect for operational constraints, and decisions that can be defended with evidence.

---

### Research basis and limitations

**Direct observation:** A front/rear difference in wheel-support appearance on hospital equipment, compared with another nearby machine. No device make or model has been confirmed; no photographs, dimensions or test records are reproduced here. The exact orientation and intended purpose remain unknown.

**Technical references:**

- Institute of Caster and Wheel Manufacturers (MHI), *Casters, Wheels, and Accessories Guide 101*: https://og.mhi.org/downloads/industrygroups/icwm/ICWM-Caster-and-Wheel-Guide-101.pdf
- Colson, *Caster Guidebook*: https://en.colson-europe.nl/service/castor-guidebook.html
- BIL Group, *Castors and Wheels Technical Reference Guide*: https://www.bilgroup.co.uk/help-hub/advice-guidance/castors-and-wheels/castors-and-wheels-technical-reference-guide/
- TENTE, *Medical beds & stretchers — caster selection*: https://www.tente.com/en-us/industry/healthcare/medical-beds-stretchers/stretcher
- U.S. FDA, *Applying Human Factors and Usability Engineering to Medical Devices* (2026): https://www.fda.gov/regulatory-information/search-fda-guidance-documents/applying-human-factors-and-usability-engineering-medical-devices

**Methods & authorship:** Independently framed observation and proposed research protocol; manufacturer literature and regulatory guidance inform the engineering discussion. The hypotheses, test design, and product recommendation are analytical proposals, not results of a controlled field study. Draft developed with AI-assisted research and editing for author review.
