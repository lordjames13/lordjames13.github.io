# Can a Reader Trace the Evidence?

**Completed website task validation · GearLab Research 17 · 14 November 2026 (New York)**

This is a narrow, actual browser task audit of the GearLab website. The operator was one AI browser agent, not Juewen Chen, a recruited user or a human usability participant. No hardware was available to measure. No headset, keyboard or mouse performance finding follows from this work.

## Question and protocol

Can an operator retrieve an exact-model source, find the current keyboard manuscript and distinguish catalog membership from evidence depth? Before the baseline run, four pass/fail criteria were written to `resources/validation/task_protocol.json`, including its timestamp and baseline source commit. Raw observations preserve the rendered DOM, route and UTC observation time. The website session was local; this audit does not itself establish public availability.

| Task | Predefined criterion | Baseline observation | Change |
|---|---|---|---|
| T1 | 60HE+ has an adjacent exact-model manufacturer link | Failed. Selected card had no source, and a specification mixed the v2 line into the older model | Added source and named fields; pinned plastic 60HE+, 1K polling; removed unsupported superiority language |
| T2 | Download directory directly lists article 11 Markdown | Failed. Articles 10–13 were absent from the main directory | Generate the directory from all numbered manuscripts and include code and raw records |
| T3 | Catalog distinguishes all five evidence states | Failed. “Comparison-ready” membership implied a stronger readiness state | Separate indexed, Compare-listed, selected-spec checked, external test linked and firsthand hardware-test records |
| T4 | Unresolved G5 series is labelled without audio superiority | Passed. Existing card explicitly withheld claims | Preserve unresolved status and show the registry boundary |

## Retained observations and repeat run

The baseline passed 1 of the 4 predefined tasks; the repeat run passed all 4. These are descriptive counts for this fixed task list, not an estimated usability success rate. The original failures are retained in `resources/validation/before.json`. The repeat run is retained separately in `after.json`; the compact result/change mapping is in `task_results.json`. They must be inspected rather than treating this article as independent evidence. See those records for observed outcomes and timestamps. The protocol was not rewritten to convert failures into passes.

Source verification also corrected the L5 HE connection from tri-mode to wired; narrowed Huntsman V3 Pro to its full-size US 1K SKU; and left legacy MADE68 Pro unresolved because the live manufacturer page describes Pro+. These are documentation corrections, not new hardware measurements. The registry names the fields checked and the remaining limits.

## What was learned and changed

Three distinct failures required three different controls: a field-level source record, a generated delivery index and explicit evidence definitions. Merely adding more prose would not repair these retrieval problems. A separate release check now reconciles Compare identities, catalog mappings, resource links, generated snapshots and downloadable pack contents. A missing charging category in the prior data object was also discovered during regression review; it is restored with cautious manufacturer-reference records and no unverified price or performance rank.

## Limits and next decision

These four tasks were selected to target known audit concerns; they are not a representative sample of all website tasks. A single AI operator does not establish human discoverability, comprehension, accessibility compliance or completion time. The before/after observations are descriptive, with no statistical significance, causal conversion inference or user-population estimate. Absence of a linked external test in this registry does not imply no external tests exist.

No published firsthand hardware-test record currently supports this portfolio's product comparisons. A meaningful next hardware study requires an actual owner-operated device record: exact SKU/firmware, computer/OS, settings, protocol, raw attempts, failures and a documented product or content change. Those observations must be collected from the real devices; they cannot be manufactured from a browser task or a proposed protocol. Product trials and consumer studies elsewhere remain explicitly proposed.

## Sources and deliverables

- [Predefined task protocol](../validation/task_protocol.json)
- [Baseline rendered observations](../validation/before.json)
- [Repeat rendered observations](../validation/after.json)
- [Results and changes](../validation/task_results.json)
- [Field-level product evidence registry](../code/product_evidence_registry.json)
- [Wooting: 60HE+ versus 60HE v2](https://wooting.io/post/the-difference-between-the-60he-and-the-60he-v2)
- [Keychron: Lemokey L5 HE](https://www.keychron.com/products/lemokey-l5-he-magnetic-switch-custom-gaming-keyboard)
- [Razer: pinned full-size Huntsman V3 Pro SKU](https://www.razer.com/gaming-keyboards/Razer-Huntsman-V3-Pro/RZ03-04970100-R3M1)
- [MelGeek: live page now describes MADE68 Pro+](https://www.melgeek.com/products/made68-pro)
