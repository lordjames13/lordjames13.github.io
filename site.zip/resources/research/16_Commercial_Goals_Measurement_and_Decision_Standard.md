# Commercial Goals, Measurement and Decision Standard

Juewen Chen · Strategy Lab revision · 14 November 2026

## 1. Decision and evidence status

The proposed decision is whether clearer, accurate gaming-mouse buying guidance improves contribution and customer understanding enough to justify its incremental cost. No campaign, observed baseline, company cost ledger, return dataset, competitor conversion median or controlled outcome was supplied. Every business input in the simulator is a constructed assumption. Unknown baselines and unapproved targets remain null in the metric contract, rather than being filled with a convenient industry number.

The portfolio now distinguishes four layers: a research question; a measurement contract; a hypothetical accounting calculation; and an evidence-based decision that cannot yet be made. These are not interchangeable. A reproducible calculation verifies arithmetic, not demand, causality or an investment recommendation.

## 2. Retired promises and replacement questions

| Earlier claim / issue | Current treatment |
|---|---|
| Conversion above an unspecified flagship median by 15% | Withdraw the benchmark claim. Define the metric, compare a usable baseline or concurrent control, and separately state relative versus percentage-point change. |
| Fit-related returns reduced 20% in 90 days | Withdraw the outcome promise. Define completed returns, delivered-order cohorts, coding coverage and follow-up maturity; 90-day enrolment is not complete observation. |
| Own top-three search slots; three posts per week | Treat visibility and content cadence as diagnostic/design choices. Define the search audit and production capacity; neither guarantees sales. |
| Universal 3.0 ROAS hurdle | Replace with explicitly scoped revenue, margin, media and fixed-cost arithmetic, followed by evidence gates. |
| Cost per attributed order called CAC | Rename to media CPA / cost per attributed placed order. True CAC requires distinct new-customer history and a cost rule. |
| Refunds hidden in an ambiguous returns cost | The live v2 model separates refund-value allowance from return handling/support; recovered inventory belongs in net product cost. |
| Negative margin hides the loss | Retain modeled losses; withhold only undefined or infeasible break-even ratios. |
| Sensitivity columns relabelled after sorting outputs | Keep the actual −20% and +20% input directions. A lower cost can correctly produce the larger contribution. |
| Positive point estimate triggers proceed | No automatic scale instruction. Require mature data, a prespecified analysis and economic hurdle, uncertainty and guardrails. |

The real-product listing must use verified retail contents and support terms. GripFit Standard / +Hump remains an independent concept, excluded from this proposed retail offer; no fit guarantee or manufacturer/local-warranty promise is established.

## 3. Percent versus percentage points

These are invented teaching counts, not business observations or approved targets.

- Conversion: 200 / 10,000 eligible unique visitors = 2.00%; 230 / 10,000 = 2.30%. Relative increase = (2.30% − 2.00%) / 2.00% = 15%; absolute change = +0.30 percentage points. Adding 15 percentage points would instead produce 17.00%.
- Confirmed fit-coded return incidence: 100 / 2,000 mature delivered orders = 5.00%; 80 / 2,000 = 4.00%. This is a 20% relative reduction and a −1.00 percentage-point change. It is not the fraction of all returns mentioning fit.
- Relative change is undefined when the baseline is zero. Show raw numerators/denominators and absolute differences; do not invent a zero or infinite relative lift.

For an external median, specify SKU selection, market/currency, channel, device, period, attribution and denominator, promotion, stock and shipping conditions. Specify whether the statistic is an unweighted median of SKU rates or a pooled rate; neither is the other. A descriptive competitor median is not a randomised counterfactual. The current portfolio has neither.

### Derive an economic hurdle, then plan detectability

As a separate invented illustration, suppose a guide adds $500 fixed cost, reaches 10,000 eligible visitors and earns $40 contribution per extra order. Holding all other traffic, costs and cannibalisation fixed, the break-even conversion difference is $500 / (10,000 × $40) = 0.00125, or +0.125 percentage points. At an assumed 2% baseline that is a 6.25% relative increase. This is an economic threshold, not an observed effect, an approved target or a statistical minimum detectable effect. A decision owner should specify the desired cushion, then plan sample size/precision against actual baseline variability and the chosen error/stopping rules. Adequate economic upside does not guarantee that a short or low-traffic pilot can distinguish it from noise.

## 4. Metric contracts

All observed baselines and approved targets below are unavailable. The proposed source is a data requirement, not evidence that access exists. Decision and finance owners must be assigned before a real pilot.

### Incremental contribution / assigned eligible visitor

- Numerator: Arm net sales minus variable costs, attributable media and fixed intervention cost allocated once under a preregistered period rule; take treatment minus control per assigned visitor.
- Denominator: All eligible unique visitors assigned to each arm, including non-buyers; stable assignment and one specified follow-up horizon.
- Unit / interpretation: USD / assigned visitor; absolute treatment-control difference
- Required source: Order/refund/finance ledger + randomisation log + documented cost allocation; not platform ROAS.
- Cohort and maturity: After attribution, refunds and cost reconciliation mature; pilot enrolment duration is not the outcome follow-up window.
- Decision role: Primary experiment outcome; hurdle and precision must be approved before launch.

### Unique-visitor purchase conversion

- Numerator: Assigned eligible visitors placing at least one qualifying paid order within the predefined conversion window; each buyer counts once. Later refunds remain separate outcomes and are not silently removed from this numerator.
- Denominator: All eligible unique visitors assigned to that arm. Do not substitute sessions, clicks or units.
- Unit / interpretation: Proportion; report both relative change and percentage-point difference
- Required source: Stable assignment/eligibility log linked to de-duplicated orders; consent and cross-device limitations documented.
- Cohort and maturity: Lock assignment date, conversion window, timezone and invalid-traffic rules before starting.
- Decision role: Secondary diagnostic; lower funnel conversion alone does not establish profit.

### Platform orders / ad click

- Numerator: Purchases credited to the specified ad report, attribution model, promoted-SKU or brand scope, and click/view basis.
- Denominator: Paid clicks in that exact report/cohort. A repeat purchase is not necessarily a new buyer.
- Unit / interpretation: Orders / click; need not be a unique-person probability
- Required source: Native ad export and its current metric definitions/report metadata. Do not sum overlapping exports.
- Cohort and maturity: Record window and reporting-date basis from the actual report; mature it before comparison. No universal 14-day assumption.
- Decision role: Acquisition diagnostic; different from unique-visitor CVR and causal incrementality.

### Confirmed fit-coded return incidence

- Numerator: Unique delivered qualifying orders with a completed fit-coded return requested inside the predefined post-delivery return window; multiple reasons count the order once.
- Denominator: All delivered qualifying orders in the same mature delivery-date cohort, including orders never returned.
- Unit / interpretation: Proportion; relative reduction and percentage-point change
- Required source: Delivery/order/return records, fixed coding rubric, reviewed ambiguous/missing reason counts.
- Cohort and maturity: Delivery date starts follow-up; require the full chosen return horizon plus processing lag for every included order.
- Decision role: Customer-experience guardrail or separate outcome. With uncoded returns this is a confirmed lower-bound rate, not fully identified actual fit-return incidence; compare coding coverage and show bounds.

### Fit share among coded returns

- Numerator: Fit-coded returned orders using the same coding rubric.
- Denominator: Returned orders with an assessed reason; separately report missing/uncoded reasons.
- Unit / interpretation: Share among returns; not return incidence
- Required source: Coded returns log with reason coverage and consistency checks.
- Cohort and maturity: Same mature order cohort and reason coding as incidence.
- Decision role: Diagnostic only: the share can fall while total returns rise.

### Attributed ROAS / ACOS

- Numerator: ROAS numerator = attributed sales on an explicitly stated gross-booked or refund-adjusted basis; ACOS numerator = media spend.
- Denominator: ROAS denominator = media spend; ACOS denominator = that same sales value.
- Unit / interpretation: ROAS ratio; ACOS proportion; reciprocals only on the same non-zero basis
- Required source: Ad export reconciled to finance; show platform sales scope and any refund adjustment separately.
- Cohort and maturity: Same currency, attribution scope, date basis, window and maturity.
- Decision role: Efficiency diagnostic. No universal 3.0 threshold; break-even depends on margin and fixed costs.

### Media cost / attributed placed order

- Numerator: Media spend on the exact same report basis.
- Denominator: Attributed placed orders, not customers; zero orders means undefined cost/order, not $0.
- Unit / interpretation: USD / attributed placed order
- Required source: Ad spend and report orders; de-duplicate cross-channel credit before a blended total.
- Cohort and maturity: Same attributed cohort/window as the purchases.
- Decision role: Called CPA/cost per order here; not customer acquisition cost.

### New-customer CAC

- Numerator: Acquisition expenditure using a documented included-cost rule.
- Denominator: Distinct newly acquired customers under a specified existing-customer lookback; cancelled/refunded customer rules stated.
- Unit / interpretation: USD / new customer
- Required source: Customer identity/history + finance + deduplicated new-customer attribution.
- Cohort and maturity: State lookback and observation horizon; do not infer from orders or a vendor label alone.
- Decision role: Not available in this portfolio; simulator does not estimate true CAC.

### Bundle choice / accessory attach

- Numerator: For bundle choice: eligible completed orders choosing the bundle; for accessory attach: qualifying accessory units/orders with the base product, as separately defined.
- Denominator: Bundle choice: all eligible completed base-or-bundle orders. Accessory attach needs its own declared eligible base-order denominator.
- Unit / interpretation: Conditional share; not visitor conversion or incremental demand
- Required source: SKU/order lines, bundle eligibility and stock logs; avoid counting bundled components twice.
- Cohort and maturity: Same availability window and completed-order definition; report stockouts separately.
- Decision role: Secondary diagnostic; purchase conditioning and standalone accessory cannibalisation can mislead.

### Organic top-three query-observation share

- Numerator: Predeclared query/device/location/time observations with an organic result in positions 1–3. Paid placements are separate.
- Denominator: All eligible observations in that planned audit, with unavailable observations recorded.
- Unit / interpretation: Share of audited observations, not market share
- Required source: Search audit with query set, geographic/device settings, schedule and placement classification.
- Cohort and maturity: Use a fixed sampling protocol and comparable audit dates.
- Decision role: Visibility diagnostic; no top-three promise and no assumed causal sales effect.

### Feature/routing comprehension

- Numerator: Participants answering a preregistered question correctly.
- Denominator: Participants answering that question; show invited/assigned counts and missing responses separately.
- Unit / interpretation: Diagnostic proportion with response coverage
- Required source: Versioned questionnaire and assignment log; do not manufacture a pass threshold after seeing results.
- Cohort and maturity: Same question, exposure and assessment window.
- Decision role: Early UX diagnostic; not purchase conversion or commercial success.

For incomplete return reasons, report confirmed fit-coded incidence and the uncoded-return count. A transparent bound can range from confirmed fit-coded returns / mature delivered orders to (confirmed fit-coded + uncoded returned orders) / the same delivered denominator, subject to the defined coding protocol. This is a missing-reason bound, not a statistical confidence interval. Changes in coding coverage can masquerade as a change in behaviour. Do not recode all unknown reasons as non-fit.

Platform report metrics have their own event scope and date rules [B1, B2]. Record the actual report/account configuration; do not impose one universal attribution window or treat clicks, sessions, units and unique buyers as interchangeable. Reconcile currency, invalid traffic and credited-order overlap before blending channels.

## 5. Pilot timeline and decision rules

A 90-day enrolment period may be a planning envelope only. A visitor arriving at its end still needs the chosen conversion horizon, delivery delay, return-request window and processing/settlement lag. Return maturity is anchored to delivery; ad maturity follows the chosen reporting/attribution convention. Show the data cutoff and maturity rule, and do not compare an immature treatment cohort with a mature baseline.

Proposed sequence: instrument and reconcile data; run a feature-comprehension pilot; specify a controlled buying-experience test; collect mature outcomes; decide against a prespecified contribution hurdle and guardrails. Hold the SKU, price, promotion, shipping and stock comparable if testing guidance alone. If several features change, the experiment estimates that package, not each mechanism independently.

Randomisation should be stable at the chosen eligible unit; analyse assigned visitors including non-buyers. Predefine the estimand, cost allocation period, practically meaningful effect, sample-size/precision plan, subgroup rules, primary outcome, guardrails and stopping rule. Check assignment balance/sample-ratio mismatch and instrumentation. A pre/post association or a user-selected guide cohort does not isolate the guide’s effect. These design ideas are informed by controlled-experiment methodology [B3]; no such study has run here.

Assess the contribution difference and uncertainty against the approved economic hurdle. Include guardrails for total returns, fit-coded returns with coding coverage, customer confusion/support burden, stock/fulfilment and product-claim accuracy. A hard harm/quality/spend stop ends the pilot. Incomplete data, immature outcomes or inadequate precision mean hold or redesign; non-significance is not evidence of no effect. Avoid repeatedly checking conventional significance and stopping at the first favourable result.

Fixed intervention cost must be allocated once on a rule fixed before analysis. Per-visitor pilot economics and a later rollout/amortisation scenario are different scopes; do not use a large imagined rollout denominator to make the pilot appear profitable. Cannibalisation, organic purchases and baseline accessory sales need a counterfactual before making an incremental-profit claim.

## 6. Current simulator v2: explicit accounting

Scope: one model period, USD, one item per placed order, at most one attributed placed order per paid click. The model has no observed auction/scale response, inventory constraint, other-product cannibalisation, customer lifetime value, company overhead, financing or income tax. Expected counts may be fractional. No assumption is an official product price or company margin.

```text
clicks = media spend / CPC
placed orders = clicks × simulated orders per paid click
booked revenue = placed orders × booked AOV after discounts, excluding tax
refund allowance = booked revenue × refund-value share
net revenue = booked revenue − refund allowance
unit contribution = booked AOV × (1 − refund-value share)
                    − net product cost − fulfilment/channel cost − return handling/support
period contribution = orders × unit contribution − media spend − fixed campaign cost
```

Refund-value share means refunded dollars / booked dollars, not returned orders / delivered orders; partial refunds make those quantities different. Expected product cost is net of recoverable inventory value and averaged over placed orders. Fulfilment/channel cost is net of fee reversals. Return-handling/support cost excludes refund principal already deducted from revenue and product recovery already netted elsewhere. Fixed campaign/content cost is charged once. A real implementation needs finance-approved ledger recognition and reconciliation, not the illustrative allowances alone.

### Worked example — invented inputs

The live default assumes booked AOV $165; media $20,000; CPC $1.20; orders/click 2.5%; CTR 1.8%; product/fulfilment/service allowances $70/$12/$8 per placed order; refund-value allowance 5%; fixed campaign cost $1,000.

| Amount in the modeled period | Output |
|---|---|
| Booked revenue | $68,750.00 |
| Refund allowance | $3,437.50 |
| Refund-adjusted net revenue | $65,312.50 |
| Variable cost | $37,500.00 |
| Contribution before acquisition | $27,812.50 |
| Media spend | $20,000.00 |
| Fixed campaign cost | $1,000.00 |
| Contribution after media and fixed cost | $6,812.50 |

The 416.6667 expected orders are never rounded before computing dollars. Media CPA is $48.00/order, all-in acquisition cost is $50.40/order, and contribution available before acquisition is $66.75/order. Booked ROAS is 3.4375; refund-adjusted net ROAS is 3.265625. Neither ratio is evidence of incremental sales or true new-customer CAC. No company-level profit is computed.

### Conditional thresholds

For positive unit contribution and positive media spend:

```text
required orders/click = (media + fixed cost) / (clicks × unit contribution)
maximum CPC = media × orders/click × unit contribution / (media + fixed cost)
break-even net ROAS = (media + fixed cost) / media
                      × net revenue per order / unit contribution
```

The default required orders/click is approximately 1.88764%; break-even net ROAS is approximately 2.46573. These are conditional arithmetic boundaries. Each holds the remaining inputs fixed. They cannot be combined as independent assurances if price, costs, conversion and CPC move together. A required conversion above 100% is infeasible under this model. Non-positive unit contribution has no finite positive-acquisition break-even. Zero orders makes per-order acquisition cost undefined; zero media makes ROAS undefined. Losses remain visible. Missing/non-finite/negative inputs, out-of-range shares and positive clicks with zero CTR are rejected rather than silently imputed or clipped.

### Stress and sensitivity

Downside and upside cases use the openly published relative multipliers in commercial_model_inputs.json. They are not confidence intervals, forecast quantiles or consumer probabilities. A stress case exceeding 100% is labelled invalid. One-factor sensitivity keeps the real −20% and +20% input outcomes in their correct columns, ranks only the absolute arithmetic spread, and preserves zero inputs as zero. A variable’s spread is not its uncertainty or empirical business importance. CTR only back-calculates impressions at fixed spend/CPC. There is no mixed-currency/count or unlabelled log-scale funnel chart.

## 7. Model scopes across the portfolio

| Exhibit / code | Unit and scope | Interpretation boundary |
|---|---|
| Live Strategy Lab v2 / reproduce_commercial_model.py | Period, placed orders; explicit refund value, variable expenses and fixed campaign cost | Current default and presets; attributed scenario arithmetic, no capacity/demand/counterfactual model. |
| Earlier memos 03–05 / reproduce_business_cases.py | Separate aggregate-allowance mouse illustration, ownership TCO and simple bundle arithmetic | Different inputs and purposes. Booked-value revenue and aggregate allowances do not separately identify the v2 refund/fixed-cost components. Per-order acquisition threshold is not true CAC. |
| Headset / keyboard GTM cases / reproduce_gtm_cases.py | Assumed seller unit revenue and pre-ad contribution-margin fractions; nine cells | Their chosen revenue/margin basis must be internally consistent. Fixed costs and attribution overlap are excluded; no causal profit or wholesale inference. Consult that case’s published assumptions. |
| Multi-device charging / reproduce_charging_launch.py | Equal eligible-visitor cohorts, optional-bundle choice, unit stock/fallback and fixed setup assumptions | Separate DTC inventory/contribution toy model, with no baseline standalone cable purchases. Choice share is not visitor conversion; behavioural fallback is assumed. |

The cases demonstrate different decision problems. Do not compare dollar totals across their unequal traffic, budgets, cost recognition or periods as if they identified the best product category. Legacy PDFs/articles remain separately dated case snapshots; this commercial standard documents the current cross-case interpretation.

## 8. Reporting query contract and quality controls

The proposed gtm_campaign_review.sql takes a finance-reviewed aggregate mart, not raw exports. Required grain is report_date × marketplace × currency × SKU × campaign × attribution window/basis × sales scope/basis × date basis × timezone. Supply one active allocation version per underlying grain. Pre-aggregate sources before linking; allocate shared media/setup cost once and reconcile total spend. The query cannot repair upstream overlap or prove correct accounting from totals.

Required fields: report_date, marketplace, currency, sku, campaign, attribution_window_days, attribution_basis, sales_scope, sales_basis, date_basis, report_timezone, allocation_version, attribution_mature, returns_mature, ad_spend_usd, ad_clicks, ad_attributed_orders, ad_attributed_net_sales_usd, attributed_variable_cost_usd, allocated_fixed_cost_usd. Monetary fields are numeric USD and costs are non-negative; explicit zero is different from missing. Cohort net sales are refund-adjusted, tax-exclusive and reconciled. Zero-sales orders may still incur costs.

The template currently supports promoted-only, click-attributed, refund-adjusted USD rows. Other currencies/bases remain withheld until an explicit adapter and reconciliation are designed. Different windows/date conventions are shown as separate groups and must not be added as independent sales populations. No conversion probability or customer identity is inferred from orders/clicks.

Duplicate grains, multiple allocation versions, missing expenses, unsupported sales bases or immature rows withhold the whole reporting group, with coverage/maturity diagnostics. The query does not drop troublesome rows in a WHERE clause to produce a favourable partial profit total. Undefined ratios use NULL; negative contribution is retained. READY_ATTRIBUTED_PROXY only means these structural rules passed, not that the data are audited, causally incremental or sufficient for a launch.

The query was exercised on synthetic fixtures covering missing cost, partial-group coverage, immature returns, duplicate rows, conflicting versions, zero orders, zero spend and wrong sales basis. It was not run against company accounts or customers.

## 9. Reproduce, edit and review

- Current model inputs: resources/code/commercial_model_inputs.json.
- Metric contracts: resources/code/business_metric_contract.json; all real baselines/targets remain null.
- Browser snapshot: assets/js/commercial_model_inputs.js; regenerate with python resources/code/build_commercial_snapshot.py.
- Independent arithmetic: python resources/code/reproduce_commercial_model.py.
- JS/Python parity and policy checks: node resources/code/check_commercial_model.js.
- Synthetic reporting tests: python resources/code/check_commercial_reporting.py.
- Current outputs: resources/code/commercial_model_results.json.

No test above validates commercial assumptions or stands in for a customer study. Keep page text, input definitions, exports and evidence pack aligned when changing the model.

## Primary sources and their limited role

- [B1] Amazon Attribution official guide: https://advertising.amazon.com/library/guides/basics-of-amazon-attribution — Distinguish reporting scope and attribution; no company baseline supplied.
- [B2] GA4 dimensions and metrics: https://support.google.com/analytics/table/13948007?hl=en — Session/user/event denominators differ; not interchangeable CVR measures.
- [B3] Kohavi and Longbotham (2023), Online Controlled Experiments and A/B Tests: https://exp-platform.com/Documents/2023-03-11EncyclopeiaMLDSABTestingFinal.pdf — Randomised experimentation and validity checks; the GearLab trial remains unrun.

Sources reviewed 14 November 2026. Amazon and GA4 documentation inform report-definition boundaries; they provide no GearLab baseline, target or manufacturer economics. The experimental reference informs validity questions, not an executed experiment. This is independent, AI-assisted portfolio analysis, not commissioned work or a claimed business result.
