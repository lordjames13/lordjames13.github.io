const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../..');function read(p){return fs.readFileSync(path.join(root,p),'utf8')}
const ctx={};vm.createContext(ctx);vm.runInContext(read('assets/js/evidence_data.js'),ctx);
const canonical=JSON.parse(read('resources/code/product_evidence_registry.json'));assert.deepStrictEqual(JSON.parse(JSON.stringify(ctx.GL_EVIDENCE)),canonical);
vm.runInContext(read('assets/js/gearlab_0.js').split('var curCat=')[0],ctx);
vm.runInContext(read('assets/js/gearlab_research.js').split('(function(){')[0],ctx);
ctx.GL_ACCESSORIES.forEach(a=>ctx.DATA.charging.items.push({name:a.name}));
const items=Object.entries(ctx.DATA).flatMap(([cat,d])=>d.items.map(p=>cat+'|'+p.name));
assert.equal(items.length,41);assert.equal(new Set(items).size,41);assert.deepStrictEqual(items.sort(),canonical.records.map(p=>p.id).sort());
for(const r of canonical.records){assert(!r.firsthand_hardware_test,'Add actual raw device records and update this check before claiming firsthand tests');if(r.checked_fields.length){assert.equal(r.source_role,'manufacturer_documentation');assert(r.source_url&&r.checked_on)}for(const e of r.external_tests)assert(e.publisher&&e.methodology&&e.url)}
const cat=read('assets/js/gearlab_3.js');vm.runInContext(cat.split('var sel=document')[0]+'})();',ctx);vm.runInContext('var CMP_READY='+cat.split('var CMP_READY=')[1].split('function cmpKey')[0],ctx);
assert.equal(ctx.CATALOG.length,417);const mapped=ctx.CATALOG.filter(p=>ctx.CMP_READY[p.brand+'|'+p.model]);assert.equal(mapped.length,41);for(const p of mapped){const a=ctx.CMP_READY[p.brand+'|'+p.model];assert(items.includes(a.cat+'|'+a.name))}
const index=read('index.html');assert(index.includes('id="catEvidenceFilter"'));assert(index.includes('Juewen_Chen_GearLab_Public_Resume.pdf'));assert(!index.includes('Juewen_Chen_Product_GTM_Resume.pdf'));
const registry=JSON.parse(read('resources/release_registry.json'));assert.equal(registry.articles.length,17);const evidence=read('resources/evidence.html');const crypto=require('crypto');
for(const a of registry.articles){const bytes=fs.readFileSync(path.join(root,'resources',a.path));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),a.sha256);assert(evidence.includes('href="'+a.path+'"'))}
if(!fs.existsSync(path.join(root,'PACK_MANIFEST.json')))for(const m of [...index.matchAll(/(?:href|src)="([^"#]+)"/g),...evidence.matchAll(/(?:href|src)="([^"#]+)"/g)]){const target=m[1].split('#')[0].split('?')[0];if(/^(https?:|mailto:|data:|tel:)/.test(target))continue;const base=evidence.includes(m[0])&&!index.includes(m[0])?'resources/':'';assert(fs.existsSync(path.resolve(root,base,target)),'Missing local file: '+base+target)}
console.log('PASS: 417 catalog identities, 41 registry/Compare mappings, field-specific evidence, public résumé, 17 canonical manuscripts, hashes and static local links.');
