/* Run from repository root: node resources/code/check_comparator_parity.js */
const fs=require('fs'),vm=require('vm'),assert=require('assert'),child=require('child_process');
const root=require('path').resolve(__dirname,'../..'),c={};vm.createContext(c);
for(const file of ['gearlab_scoring_data.js','gearlab_1.js'])vm.runInContext(fs.readFileSync(root+'/assets/js/'+file,'utf8'),c);
const m=c.GL_SCORE_INPUTS,o=c.glOptions(),p=m.items[0];
const py=JSON.parse(child.execFileSync('python',[root+'/resources/code/GearLab_Comparator_Reproducibility.py'],{encoding:'utf8'}));
const cases=[{weights:[5,5]},{weights:[8,2]},{weights:[2,8]},{weights:[0,5]},{weights:[5,0]}];
function near(a,b){assert(Math.abs(a-b)<1e-10,`${a} != ${b}`)}
for(const r of py.default)near(c.wScore(m.items.find(p=>p.name===r[0]),[5,5],o).total,r[1]);
for(const row of py.retiredStructuralAudit){const r=c.glLegacyAudit(c.GL_RETIRED_AUDIT).find(x=>x.name===row.name);for(const key of ['old','collapsed','removed'])near(r[key],row[key]);}
for(const corner of py.weightCorners){const r=c.glRank(m.defaultSelection.map(i=>m.items[i]),corner.factors.map(f=>f*5),o);r.forEach((x,i)=>{assert.equal(x.p.name,corner.ranking[i][0]);near(x.total,corner.ranking[i][1])});}
for(const weights of [[5,5],[8,2],[2,8],[5,0],[0,5]])for(const p of m.items){const r=c.wScore(p,weights,o);if(p.source)assert(r.total!==null);else assert.equal(r.total,null);}
assert.equal(c.wScore(p,[0,0],o).total,null);
assert.equal(c.wScore({...p,price:null},[5,5],o).total,null);
near(c.wScore({...p,price:null},[5,0],o).total,8);
assert.equal(c.wScore(p,[5,5],{...o,fit:{[p.id]:'fail'}}).total,null);
assert.equal(c.wScore(m.items[1],[5,5],{...o,connection:'bt'}).total,null);
assert.equal(c.wScore(p,[5,0],{...o,budget:100}).total,null);
assert.equal(c.wScore(p,[5,5],{...o,prices:{[p.id]:-1}}).total,null);
assert.equal(c.wScore(p,[5,5],{...o,anchors:{mass:[40,40],price:[50,200]}}).total,null);
near(c.wScore(p,[5,5],o).total,c.wScore(p,[10,10],o).total);
near(c.glRank([p],[5,5],o)[0].total,c.glRank(m.items,[5,5],o).find(r=>r.p.id===p.id).total);
const canonical=JSON.parse(fs.readFileSync(root+'/resources/code/GearLab_Comparator_Model_Inputs.json','utf8'));
assert.deepEqual(JSON.parse(JSON.stringify(m)),canonical);
console.log('PASS: JavaScript/Python defaults, four weight corners, historical structural audit, evidence withholding, constraints, anchors and canonical snapshot parity.');
