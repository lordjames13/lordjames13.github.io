/* Run from repo root: node resources/code/check_commercial_model.js */
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert'),cp=require('child_process');
const root=path.resolve(__dirname,'../..'),c={};vm.createContext(c);
for(const f of ['commercial_model_inputs.js','commercial_model.js'])vm.runInContext(fs.readFileSync(root+'/assets/js/'+f,'utf8'),c);
const config=c.BIZ_MODEL_CONFIG,a=config.default;
const py=JSON.parse(cp.execFileSync('python',[root+'/resources/code/reproduce_commercial_model.py'],{encoding:'utf8'}));
function compare(x,y){for(const k of Object.keys(y)){if(typeof y[k]==='number')assert(Math.abs(x[k]-y[k])<1e-7,`${k}: ${x[k]} != ${y[k]}`);else if(y[k]===null||typeof y[k]==='boolean')assert.strictEqual(x[k],y[k],k)}}
compare(c.bizCalculate(a),py.default);
for(const k of Object.keys(config.presets))compare(c.bizCalculate(config.presets[k].inputs),py.presets[k]);
config.stressCases.forEach((d,i)=>compare(c.bizScenario(a,d).result,py.stressCases[i].result));
for(const row of c.bizSensitivity(a)){const p=py.sensitivity.find(x=>x.key===row.key);compare(row,p)}
const r=c.bizCalculate(a);assert(Math.abs(c.bizCalculate({...a,cvr:r.breakEvenCvr}).contributionAfterAcquisition)<1e-7);assert(Math.abs(c.bizCalculate({...a,cpc:r.breakEvenCpc}).contributionAfterAcquisition)<1e-7);
assert.equal(c.bizCalculate({...a,cvr:0}).mediaCostPerOrder,null);
assert.equal(c.bizCalculate({...a,budget:0}).netRoas,null);
assert(c.bizCalculate({...a,price:20}).contributionAfterAcquisition<0);
assert.equal(c.bizCalculate({...a,price:20}).breakEvenCvr,null);
for(const p of [{...a,cpc:0},{...a,cvr:1.1},{...a,refund:NaN},{...a,price:null},{...a,ctr:0},{...a,budget:1e308,cpc:.01}])assert(!c.bizCalculate(p).valid);
const fc=c.bizSensitivity(a).find(x=>x.key==='fc');assert(fc.minus>fc.plus,'lower cost must improve contribution; do not sort endpoints into mislabeled columns');
assert(!c.bizScenario({...a,cvr:.9},config.stressCases[2]).result.valid);
assert.equal(c.bizCalculate({...a,ctr:.04}).contributionAfterAcquisition,r.contributionAfterAcquisition);
assert.deepEqual(JSON.parse(JSON.stringify(config)),JSON.parse(fs.readFileSync(root+'/resources/code/commercial_model_inputs.json','utf8')));
assert.deepEqual(JSON.parse(JSON.stringify(c.BIZ_METRIC_CONTRACT)),JSON.parse(fs.readFileSync(root+'/resources/code/business_metric_contract.json','utf8')));
for(const metric of c.BIZ_METRIC_CONTRACT.metrics){assert.strictEqual(metric.observedBaseline,null);assert.strictEqual(metric.approvedTarget,null)}
console.log('PASS: JS/Python defaults, presets, stresses and sensitivity agree; refunds counted once; break-even identities, visible losses, zero-order/zero-spend handling, invalid stress cases, unchanged CTR contribution and unknown baselines verified.');
