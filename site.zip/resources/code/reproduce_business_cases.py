#!/usr/bin/env python3
"""Reproduce GearLab Phase 4 hypothetical exhibits; no company actuals.

Run: python reproduce_business_cases.py
Outputs: strategy_exhibit_values.json, strategy_exhibits.csv in the same directory.
"""
from __future__ import annotations
import csv, json
from pathlib import Path

OUT=Path(__file__).resolve().parent

def funnel(price:float,unit_cost:float,cvr:float,budget:float=20000,cpc:float=1.2):
    clicks=budget/cpc
    orders=clicks*cvr
    per=price-unit_cost
    return {
        'price':price,'unit_variable_cost':unit_cost,'click_to_purchase_cvr':cvr,
        'ad_budget':budget,'cpc':cpc,'clicks':clicks,'expected_orders':orders,
        'contribution_per_order_before_media':per,
        'expected_revenue':orders*price,
        'expected_contribution_after_media':orders*per-budget,
        'break_even_cvr':cpc/per if per>0 else None,
        'break_even_cost_per_attributed_order':per if per>0 else None,
        'break_even_roas':price/per if per>0 else None,
    }

def tco_three_year(purchase:float,annual_consumables:float,annual_expected_service:float,discount:float):
    return purchase+sum((annual_consumables+annual_expected_service)/((1+discount)**t) for t in (1,2,3))

prem=funnel(185,99,.028)
val=funnel(99,71,.032)
down=funnel(185,99,.01)
vals={
 'assumption_note':'All numerical inputs are deliberately invented educational cases, not real brand financial data, demand forecasts or benchmark conversion rates.',
 'mouse_value':val,
 'mouse_premium':prem,
 'mouse_premium_downside':down,
 'premium_cvr_to_match_modeled_value':.032*(99-71)/(185-99),
 'vacuum_tco_example':{'purchase':850,'annual_consumables':95,'annual_expected_service':45,'discount_rate':.08,'years':3,'present_value':tco_three_year(850,95,45,.08)},
 'charger_standalone':{'price':79,'all_variable_cost':42,'contribution_before_acquisition':79-42},
 'charger_bundle':{'price':99,'all_variable_cost':54,'contribution_before_acquisition':99-54},
 'bundle_incremental_contribution_per_switched_order':(99-54)-(79-42),
 'bundle_incremental_contribution_per_previous_buyer_25pct_attach':.25*((99-54)-(79-42)),
}
assert round(val['expected_contribution_after_media'])==-5067
assert round(prem['expected_contribution_after_media'])==20133
assert round(down['expected_contribution_after_media'])==-5667
assert abs(prem['break_even_cvr']-.013953488372093023)<1e-10
assert round(vals['vacuum_tco_example']['present_value'])==1211
assert vals['bundle_incremental_contribution_per_switched_order']==8
(OUT/'strategy_exhibit_values.json').write_text(json.dumps(vals,indent=2,ensure_ascii=False),encoding='utf8')
rows=[]
for title,obj in vals.items():
    if isinstance(obj,dict):
        for key,value in obj.items():
            if isinstance(value,(int,float)):
                rows.append({'case':title,'metric':key,'value_unrounded':value,'status':'HYPOTHETICAL'})
    elif isinstance(obj,(int,float)):
        rows.append({'case':title,'metric':title,'value_unrounded':obj,'status':'HYPOTHETICAL'})
with (OUT/'strategy_exhibits.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['case','metric','value_unrounded','status'],lineterminator='\n');w.writeheader();w.writerows(rows)
print('PASS: independent arithmetic checks')
print('Value scenario:',round(val['expected_contribution_after_media']))
print('Premium scenario:',round(prem['expected_contribution_after_media']))
print('Downside scenario:',round(down['expected_contribution_after_media']))
print('Vacuum TCO:',round(vals['vacuum_tco_example']['present_value']))
print('Bundle incremental contribution:',vals['bundle_incremental_contribution_per_switched_order'])
