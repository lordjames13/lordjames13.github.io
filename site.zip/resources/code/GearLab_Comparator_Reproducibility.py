#!/usr/bin/env python3
"""Independent standard-library reproduction of the conditional model, not input validation by experiment.
Run with an optional path to GearLab_Comparator_Model_Inputs.json.
Retired editorial ratings are used ONLY for the explicitly labelled structural audit.
"""
import itertools
import json
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

def finite(x):
    return isinstance(x, (float, int)) and not isinstance(x, bool) and math.isfinite(x)

def utility(value, anchors):
    if not finite(value) or value < 0:
        return None
    return max(0, min(10, 10 * (anchors[1] - value) / (anchors[1] - anchors[0])))

def score(p, weights, anchors, *, fit='unknown', connection='any', budget=None, quote=None):
    if len(weights) != 2 or any(not finite(w) or w < 0 for w in weights) or sum(weights) == 0:
        return None
    if any(len(anchors[k]) != 2 or any(not finite(x) or x < 0 for x in anchors[k]) or anchors[k][1] <= anchors[k][0] for k in ['mass', 'price']):
        return None
    if budget is not None and (not finite(budget) or budget < 0):
        return None
    if quote is not None and (not finite(quote) or quote < 0):
        return None
    price = p['price'] if quote is None else quote
    if fit == 'fail' or (connection == 'bt' and p['bluetooth'] is not True):
        return None
    if budget is not None and (not finite(price) or price > budget):
        return None
    values = [utility(p['mass'], anchors['mass']), utility(price, anchors['price'])]
    if any(w > 0 and (v is None or not p.get('source')) for w, v in zip(weights, values)):
        return None
    return sum(w * v for w, v in zip(weights, values) if w > 0) / sum(weights)

def rank(items, weights, anchors, **kwargs):
    pairs = [(p['name'], score(p, weights, anchors, **kwargs)) for p in items]
    return sorted([(n, x) for n, x in pairs if x is not None], key=lambda r: (-r[1], r[0]))

def structural(a):
    rows = []
    for i in a['selection']:
        p = a['items'][i]
        values = [p['light'], p['comfort'], p['value'], p['trust'], p['fit']['claw'], p['hand']['m']]
        shape = (6*p['comfort'] + 7*p['fit']['claw'] + 5*p['hand']['m'])/18
        other = 6*p['light'] + 5*p['value'] + 5*p['trust']
        rows.append({'name': p['name'], 'old': sum(w*v for w,v in zip(a['weights'],values))/34, 'collapsed': (other+6*shape)/22, 'removed':other/16})
    return rows

def reproduce(path):
    m=json.loads(Path(path).read_text())
    a=json.loads(Path(path).with_name('GearLab_Retired_Scoring_Audit.json').read_text())
    anchors=m['anchors']; sel=[m['items'][i] for i in m['defaultSelection']]
    baseline=rank(sel,m['weights'],anchors)
    corners=[]
    for factors in itertools.product([.8,1.2], repeat=2):
        r=rank(sel,[w*f for w,f in zip(m['weights'],factors)],anchors)
        corners.append({'factors':factors,'ranking':r,'exactTie':[n for n,v in r if abs(v-r[0][1])<1e-9]})
    # Assertions test the decision policy and mathematical properties, not whether people prefer these mice.
    p=sel[0]
    assert [utility(x,[40,80]) for x in [30,40,50,60,70,80,90]]==[10,10,7.5,5,2.5,0,0]
    assert score(p,[0,0],anchors) is None
    assert score(p,[-1,5],anchors) is None
    assert score(p,[5,5],{'mass':[80,40],'price':[50,200]}) is None
    missing=dict(p,price=None)
    assert score(missing,[5,5],anchors) is None  # must not renormalise per product
    assert score(missing,[5,0],anchors)==utility(p['mass'],anchors['mass'])
    assert score(missing,[5,0],anchors,budget=200) is None
    assert score(p,[5,5],anchors,fit='unknown')==score(p,[5,5],anchors,fit='pass')
    assert score(p,[10,0],anchors,fit='fail') is None
    assert score(sel[1],[5,5],anchors,connection='bt') is None
    assert score(p,[5,5],anchors,budget=100) is None
    assert score(p,[5,5],anchors,quote=-1) is None
    assert score(p,[5,5],anchors,quote=99)>score(p,[5,5],anchors)
    assert score(dict(p,mass=p['mass']-1),[5,5],anchors)>=score(p,[5,5],anchors)
    assert score(p,[10,10],anchors)==score(p,[5,5],anchors)
    assert rank([p],m['weights'],anchors)[0][1]==dict(baseline)[p['name']]
    assert score(dict(p,source=None),[5,5],anchors) is None
    assert all(score(p,[5,5],anchors) is None for p in m['items'][3:])
    audit=structural(a)
    assert max(audit,key=lambda x:x['old'])['name']=='G PRO X SUPERLIGHT 2'
    assert max(audit,key=lambda x:x['collapsed'])['name']=='ROG Harpe II Ace'
    # Grouping with the original combined weight must leave every historical score unchanged.
    for i,row in zip(a['selection'],audit):
        p=a['items'][i]
        shape=(6*p['comfort']+7*p['fit']['claw']+5*p['hand']['m'])/18
        same=(6*p['light']+18*shape+5*p['value']+5*p['trust'])/34
        assert abs(same-row['old'])<1e-12
    return {'modelVersion':2,'interpretation':'Conditional preference; not overall quality. Corners are not probabilities. Reference prices are not current comparable offers.','default':baseline,'weightCorners':corners,'retiredStructuralAudit':audit,'verification':'All policy and numerical assertions passed.'}

if __name__=='__main__':
    print(json.dumps(reproduce(sys.argv[1] if len(sys.argv)>1 else HERE/'GearLab_Comparator_Model_Inputs.json'),indent=2))
