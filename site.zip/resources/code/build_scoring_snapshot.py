#!/usr/bin/env python3
"""Regenerate the buildless browser snapshot after editing canonical JSON inputs.
Run from the repository: python resources/code/build_scoring_snapshot.py
"""
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
current=json.loads((HERE/'GearLab_Comparator_Model_Inputs.json').read_text())
retired=json.loads((HERE/'GearLab_Retired_Scoring_Audit.json').read_text())
text='/* Generated snapshot of resources/code/GearLab_Comparator_Model_Inputs.json. */\nvar GL_SCORE_INPUTS = '+json.dumps(current,ensure_ascii=False,indent=2)+';\n'
text+='\n/* Retired inputs: structural audit only, never live scoring. */\nvar GL_RETIRED_AUDIT = '+json.dumps(retired,ensure_ascii=False,indent=2)+';\n'
(ROOT/'assets/js/gearlab_scoring_data.js').write_text(text)
print('Updated browser scoring snapshot from canonical JSON.')
