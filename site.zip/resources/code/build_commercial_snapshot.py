#!/usr/bin/env python3
"""Regenerate the browser data snapshot after editing the canonical JSON contracts."""
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent
text='/* Generated from resources/code/commercial_model_inputs.json and business_metric_contract.json. */\n'
for filename,name in [('commercial_model_inputs.json','BIZ_MODEL_CONFIG'),('business_metric_contract.json','BIZ_METRIC_CONTRACT')]:
    data=json.loads((HERE/filename).read_text())
    text+='var '+name+' = '+json.dumps(data,ensure_ascii=False,indent=2)+';\n'
(HERE.parent.parent/'assets/js/commercial_model_inputs.js').write_text(text)
print('Updated commercial browser snapshot.')
