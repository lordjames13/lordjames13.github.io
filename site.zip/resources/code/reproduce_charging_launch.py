"""Standard-library reproduction of the multi-device charging GTM case.

All business inputs are assumptions. Run with Python 3; outputs live beside
this file. This model does not demonstrate actual demand, causal lift or ROI.
"""
from pathlib import Path
import csv
import json
import math

ROOT = Path(__file__).resolve().parent


def evaluate(p, conversion, bundle_choice, cable_units, fallback):
    visitors = p["eligible_visitors"]
    available = p["charger_units_available"]
    would_buy = min(visitors * conversion, available)
    requested = would_buy * bundle_choice
    bundled = min(requested, cable_units)
    lost = (requested - bundled) * (1 - fallback)
    standalone = would_buy - bundled - lost
    single_contribution = p["standalone_net_price_usd"] - p["standalone_all_variable_cost_usd"]
    bundle_contribution = p["bundle_net_price_usd"] - p["bundle_all_variable_cost_usd"]
    contribution = standalone * single_contribution + bundled * bundle_contribution - p["incremental_pilot_setup_cost_usd"]
    baseline = min(visitors * p["control_conversion"], available) * single_contribution
    return dict(
        evidence_status="HYPOTHETICAL_NOT_OBSERVED", conversion=conversion,
        bundle_choice=bundle_choice, cable_units=cable_units, fallback_rate=fallback,
        modeled_standalone_orders=standalone, modeled_bundle_orders=bundled,
        modeled_lost_orders=lost, contribution_after_pilot_setup_usd=contribution,
        control_contribution_usd=baseline, incremental_contribution_usd=contribution-baseline,
        incremental_contribution_per_eligible_visitor_usd=(contribution-baseline)/visitors)


if __name__ == "__main__":
    p = json.loads((ROOT / "charging_launch_inputs.json").read_text())
    rows = []
    for cvr in p["sensitivity_conversion"]:
        for attach in p["sensitivity_bundle_choice"]:
            rows.append(dict(scenario_family="conversion_and_bundle_choice",
                             **evaluate(p, cvr, attach, 400, 1)))
    for fallback in p["inventory_standalone_fallback_rates"]:
        rows.append(dict(scenario_family="60_cable_inventory_stress",
                         **evaluate(p, .03, .3, p["inventory_cable_units"], fallback)))
    single = p["standalone_net_price_usd"]-p["standalone_all_variable_cost_usd"]
    delta = p["bundle_net_price_usd"]-p["bundle_all_variable_cost_usd"]-single
    baseline = p["eligible_visitors"]*p["control_conversion"]*single
    summary = dict(
        evidence_status=p["evidence_status"], baseline_contribution_usd=baseline,
        standalone_contribution_usd=single, bundle_contribution_usd=single+delta,
        incremental_contribution_per_substituted_bundle_usd=delta,
        break_even_conversion_at_30pct_bundle_choice=(baseline+p["incremental_pilot_setup_cost_usd"])/(p["eligible_visitors"]*(single+.3*delta)),
        minimum_whole_bundles_to_cover_pilot_setup_at_unchanged_conversion=math.ceil(p["incremental_pilot_setup_cost_usd"]/delta),
        unrestricted_example=evaluate(p,.03,.3,400,1),
        inventory_stress=[r for r in rows if r["scenario_family"]=="60_cable_inventory_stress"])
    # Check accounting and the decision-changing examples, not a demand forecast.
    for r in rows:
        assert r["modeled_bundle_orders"] <= r["cable_units"]
        assert r["modeled_bundle_orders"]+r["modeled_standalone_orders"]+r["modeled_lost_orders"] <= p["charger_units_available"]+1e-8
    assert math.isclose(summary["unrestricted_example"]["incremental_contribution_usd"], 220)
    assert math.isclose(summary["inventory_stress"][-1]["incremental_contribution_usd"], -20)
    assert math.isclose(summary["inventory_stress"][0]["incremental_contribution_usd"], -1070)
    with (ROOT / "charging_launch_scenarios.csv").open("w", newline="") as f:
        writer=csv.DictWriter(f, fieldnames=rows[0], lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)
    (ROOT / "charging_launch_summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    print("PASS: 12 hypothetical scenarios; inventory + accounting checks; key incremental values +220 / -20 / -1070 USD.")
