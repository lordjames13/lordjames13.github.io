"""Build the reviewed static portfolio; never publish the original private résumé."""
from pathlib import Path
import shutil,json
ROOT=Path(__file__).resolve().parents[2]; out=ROOT/'dist'
out.mkdir(exist_ok=True)
# Only this generated output directory is replaced. Original source is retained.
for p in out.iterdir():
 if p.is_symlink() or p.is_file():p.unlink()
 elif p.is_dir():shutil.rmtree(p)
shutil.copy2(ROOT/'index.html',out/'index.html')
shutil.copytree(ROOT/'assets',out/'assets')
shutil.copytree(ROOT/'resources',out/'resources',ignore=shutil.ignore_patterns('Juewen_Chen_Product_GTM_Resume.pdf','__pycache__','*.pyc','GearLab_Research_and_Code_Pack'))
assert not (out/'resources/resume/Juewen_Chen_Product_GTM_Resume.pdf').exists()
assert (out/'resources/resume/Juewen_Chen_GearLab_Public_Resume.pdf').read_bytes().startswith(b'%PDF')
assert (out/'resources/GearLab_Research_and_Code_Pack.zip').read_bytes().startswith(b'PK')
print('Built public static output; original résumé and generated pack directory excluded.')
