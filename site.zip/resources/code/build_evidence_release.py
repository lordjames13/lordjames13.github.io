"""Generate the resource directory, standalone evidence pack and integrity inventory."""
from pathlib import Path
import json,hashlib,html,shutil,zipfile,subprocess
ROOT=Path(__file__).resolve().parents[2]; RES=ROOT/'resources'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def heading(p):return next((s[2:].strip() for s in p.read_text().splitlines() if s.startswith('# ')),p.stem)
articles=[]
for p in sorted((RES/'research').glob('[0-9][0-9]_*.md')):
 n=int(p.name[:2]); status='Completed website task audit; one AI operator' if n==17 else 'Engineering proposal; feasibility unproven' if n==15 else 'Completed source/method audit; no hardware tests' if n in [1,2,6,14,16] else 'Field observation; no controlled study' if n in [7,8,9] else 'Desk research / proposal; scenario inputs hypothetical'
 articles.append(dict(number=n,title=heading(p),path=p.relative_to(RES).as_posix(),evidence_type=status,sha256=digest(p)))
files=[dict(path=p.relative_to(RES).as_posix(),sha256=digest(p),bytes=p.stat().st_size) for folder in ['code','validation'] for p in sorted((RES/folder).glob('*')) if p.is_file() and p.suffix in ['.py','.js','.json','.csv','.sql','.txt']]
registry=dict(release_id='2026-11-14-evidence-closure',date='2026-11-14',articles=articles,files=files)
(RES/'release_registry.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n')
esc=html.escape
rows=''.join('<tr><td>'+str(a['number']).zfill(2)+'</td><td><a href="'+a['path']+'">'+esc(a['title'])+'</a><small>'+esc(a['path'])+'</small></td><td>'+esc(a['evidence_type'])+'</td></tr>' for a in articles)
links=''.join('<li><a href="'+f['path']+'">'+esc(f['path'])+'</a></li>' for f in files)
style='body{margin:0;background:#f6f7f9;color:#172b3a;font:16px/1.7 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:40px 24px}a{color:#135d73;text-underline-offset:3px}nav{display:flex;justify-content:space-between;gap:20px}h1{font-size:clamp(30px,5vw,52px);letter-spacing:-.03em;line-height:1.1}h2{margin-top:42px}table{width:100%;border-collapse:collapse}td,th{text-align:left;vertical-align:top;padding:15px 10px;border-bottom:1px solid #d3dbe1}small{display:block;font:11px/1.5 monospace;color:#526572;overflow-wrap:anywhere}.boundary{border-left:3px solid #226477;background:#eaf0f3;padding:18px 24px}.code-list{columns:2;column-gap:45px;padding-left:20px;font-size:14px;overflow-wrap:anywhere}.code-list li{break-inside:avoid;margin-bottom:10px}.table-wrap{overflow:auto}footer{padding:35px 0;font-size:13px;color:#526572}@media(max-width:650px){.code-list{columns:1}td,th{padding:12px 5px;font-size:13px}}'
page='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Research, Code &amp; Validation — GearLab</title><style>'+style+'</style></head><body><main><nav><b>GEARLAB / EVIDENCE</b><a href="../index.html#home">Back to GearLab</a></nav><p>RELEASE 2026-11-14 · 17 MANUSCRIPTS</p><h1>Research you can inspect.</h1><p>Manuscripts, source records, reproducible models and retained task failures. The current directory is generated from the same files included in the download.</p><div class="boundary">417 indexed models and 41 Compare entries describe coverage. Only named fields carry a selected-spec check. External test links are separate from GearLab testing. There are <b>0 published firsthand hardware-test records</b>. The completed website task audit uses one AI operator; commercial scenarios remain hypothetical.</div><p><a href="GearLab_Research_and_Code_Pack.zip">Download complete research and code pack (ZIP)</a> · <a href="release_registry.json">Inspect release registry and SHA-256 hashes</a> · <a href="resume/Juewen_Chen_GearLab_Public_Resume.pdf">Public résumé with GearLab project (PDF)</a></p><h2>All research manuscripts</h2><div class="table-wrap"><table><thead><tr><th>No.</th><th>Canonical title / download</th><th>Evidence boundary</th></tr></thead><tbody>'+rows+'</tbody></table></div><h2>Code, data and raw validation</h2><p>Product sources and unresolved variants: <a href="code/product_evidence_registry.json">product evidence registry</a>. All listed code and data files are downloadable; scripts are source files, not hosted APIs.</p><ul class="code-list">'+links+'</ul><h2>Maintenance and reproduction</h2><p>Read <a href="README.md">the maintenance and reproduction guide</a>. A reproduced calculation verifies arithmetic under its assumptions; it does not validate manufacturer claims or hypothetical business inputs. The original failures remain in the download after fixes.</p><footer>Independent, AI-assisted portfolio by Juewen Chen. Product names and marks belong to their owners. No manufacturer endorsement.</footer></main></body></html>'
(RES/'evidence.html').write_text(page)
readme='''# GearLab — Research, Code and Validation

Release: 2026-11-14-evidence-closure. Maintainer: Juewen Chen.

This independent, AI-assisted portfolio distinguishes indexed models, descriptive Compare entries, selected-field source checks, linked external tests and published firsthand hardware tests. Zero firsthand hardware-test records are published in this release. Software task validation is a separate category; one AI operator is not a human usability sample. Scenario economics are hypothetical.

## Inspect

`resources/release_registry.json` indexes every numbered manuscript and downloadable code/raw record with its SHA-256. Article 17 preserves the predefined protocol, baseline failures, fixes and repeat observations. `resources/code/product_evidence_registry.json` defines evidence states and checked fields. Missing fields and ambiguous variants are retained as unknown, not imputed or ranked.

## Reproduce from the repository or extracted pack root

```bash
node resources/code/check_evidence_release.js
node resources/code/check_comparator_parity.js
node resources/code/check_commercial_model.js
python resources/code/check_commercial_reporting.py
python resources/code/GearLab_Comparator_Reproducibility.py
python resources/code/reproduce_business_cases.py
```

Python model checks use the standard library. Node checks require Node.js. The public résumé generator additionally needs ReportLab and DejaVu fonts. Snapshot generation is a maintainer action; it does not retrieve fresh product facts.

## Make a future change

1. Update exact model/region, source URL, named checked fields, date and limitations in the canonical evidence registry. Do not infer a product-wide verification badge from one linked field. Add an external test only with publisher/method and exact-model scope. Firsthand status requires a real device/protocol/raw-result record.
2. Run `python resources/code/build_evidence_snapshot.py`; card data in `assets/js/gearlab_0.js` and catalog aliases must agree with registry identities. Article titles come from their first Markdown heading; old route slugs remain stable.
3. Update completed work versus proposed work explicitly. Preserve original task failures; do not overwrite a protocol to change its criteria after a run.
4. Run the checks above. Run `python resources/code/build_evidence_release.py` to regenerate the directory, registry, standalone ZIP and integrity inventory; run the evidence check again. Verify static local links and visible routes.
5. Deploy a reviewed public static build that excludes the original private résumé and development files. Keep the source repository private. Check the root, evidence page, public résumé, registry and ZIP with an HTTP client that sends no cookies or authorization. Verify PDF/ZIP signatures, not only status codes. Record the deployment version separately from source content hashes.

The public résumé omits the phone number and includes the GearLab project. The original résumé remains in the private source repository and must not be copied to the public build. The ZIP contains public research, code and raw website observations only; no résumé or private repository history.
'''
(RES/'README.md').write_text(readme)
pack=RES/'GearLab_Research_and_Code_Pack';shutil.rmtree(pack,ignore_errors=True);pack.mkdir()
for folder in ['research','code','validation']:
 shutil.copytree(RES/folder,pack/'resources'/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copy2(RES/'evidence.html',pack/'resources/evidence.html');shutil.copy2(RES/'release_registry.json',pack/'resources/release_registry.json');shutil.copy2(RES/'README.md',pack/'README.md')
shutil.copytree(ROOT/'assets/js',pack/'assets/js');shutil.copy2(ROOT/'index.html',pack/'index.html')
# The pack is for offline calculation, not a second complete image-bearing website.
manifest={p.relative_to(pack).as_posix():dict(bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(pack.rglob('*')) if p.is_file()}
(pack/'PACK_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(RES/'GearLab_Research_and_Code_Pack.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(pack.rglob('*')):
  if p.is_file():z.write(p,'GearLab_Research_and_Code_Pack/'+p.relative_to(pack).as_posix())
old=json.loads((ROOT/'manifest.json').read_text());old['build']='GearLab Evidence Closure — Phase 14';old['date']='2026-11-14'
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).decode().split('\0')
old['files']={name:dict(bytes=(ROOT/name).stat().st_size,sha256=digest(ROOT/name)) for name in sorted(set(paths)) if name and name!='manifest.json' and (ROOT/name).is_file()}
(ROOT/'manifest.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n')
print('Generated',len(articles),'manuscripts,',len(files),'code/raw records; pack and inventory refreshed.')
