#!/usr/bin/env python3
"""Independent reproduction of Strategy Lab model v2. Inputs are constructed examples.
Usage: python resources/code/reproduce_commercial_model.py [path/to/inputs.json]
Prints JSON only; no external data, account access or causal estimates.
"""
import itertools
import json
import math
import sys
from pathlib import Path

KEYS=('price','budget','cpc','ctr','cvr','pc','fc','rc','refund','fixed')

def valid_number(x):
    return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)

def calculate(a):
    errors=[]
    for k in KEYS:
        if not valid_number(a.get(k)): errors.append(k+' must be a finite number.')
    if errors:return {'valid':False,'errors':errors}
    for k in KEYS:
        if a[k]<0:errors.append(k+' cannot be negative.')
    if a['cpc']<=0:errors.append('CPC must be positive.')
    for k in ['ctr','cvr','refund']:
        if a[k]>1:errors.append(k+' must be between 0% and 100% under this model.')
    if a['budget']>0 and a['ctr']==0:errors.append('Positive paid clicks and zero CTR are inconsistent.')
    if errors:return {'valid':False,'errors':errors}
    clicks=a['budget']/a['cpc'];impressions=clicks/a['ctr'] if clicks else 0
    orders=clicks*a['cvr'];booked=orders*a['price'];refunds=booked*a['refund'];net=booked-refunds
    unit_net=a['price']*(1-a['refund']);unit_cost=a['pc']+a['fc']+a['rc'];margin=unit_net-unit_cost
    variable=orders*unit_cost;before=orders*margin;acquisition=a['budget']+a['fixed'];after=before-acquisition
    if not all(math.isfinite(x) for x in [clicks,impressions,orders,booked,refunds,net,unit_net,unit_cost,margin,variable,before,acquisition,after]):
        return {'valid':False,'errors':['Input magnitude exceeds the finite arithmetic range; reduce the scenario scale.']}
    factor=acquisition/a['budget'] if a['budget']>0 else None
    be_cvr=(a['cpc']/margin)*factor if margin>0 and clicks>0 else None
    result=dict(valid=True,errors=[],clicks=clicks,impressions=impressions,orders=orders,bookedRevenue=booked,refundAllowance=refunds,netRevenue=net,unitNetRevenue=unit_net,unitCost=unit_cost,unitContribution=margin,variableCost=variable,contributionBeforeAcquisition=before,contributionAfterAcquisition=after,mediaSpend=a['budget'],fixedCampaignCost=a['fixed'],mediaCostPerOrder=a['budget']/orders if orders>0 else None,allInCostPerOrder=acquisition/orders if orders>0 else None,bookedRoas=booked/a['budget'] if a['budget']>0 else None,netRoas=net/a['budget'] if a['budget']>0 else None,netAcos=a['budget']/net if net>0 else None,breakEvenCvr=be_cvr,breakEvenCvrFeasible=be_cvr is not None and be_cvr<=1,breakEvenNetRoas=(acquisition/a['budget'])*unit_net/margin if margin>0 and a['budget']>0 else None,breakEvenBookedRoas=(acquisition/a['budget'])*a['price']/margin if margin>0 and a['budget']>0 else None,breakEvenCpc=a['cvr']*margin/factor if margin>0 and a['budget']>0 else None)
    if any(isinstance(v,(int,float)) and not isinstance(v,bool) and not math.isfinite(v) for v in result.values()):
        return {'valid':False,'errors':['Input magnitude exceeds the finite arithmetic range; reduce the scenario scale.']}
    return result

def stress(a,definition):
    b=dict(a)
    for k,f in definition['factors'].items():b[k]*=f
    return {'label':definition['label'],'inputs':b,'result':calculate(b)}

def sensitivity(a,fields):
    rows=[]
    for f in fields:
        k=f['key']
        if k=='ctr':continue
        low=dict(a);high=dict(a);low[k]*=.8;high[k]*=1.2
        l=calculate(low);h=calculate(high)
        minus=l.get('contributionAfterAcquisition');plus=h.get('contributionAfterAcquisition')
        rows.append(dict(key=k,label=f['label'],lowInput=low[k],highInput=high[k],minus=minus,plus=plus,spread=abs(plus-minus) if l['valid'] and h['valid'] else None))
    return sorted(rows,key=lambda r:float('-inf') if r['spread'] is None else r['spread'],reverse=True)

def verify(config):
    a=config['default'];r=calculate(a)
    assert math.isclose(r['bookedRevenue'],68750)
    assert math.isclose(r['refundAllowance'],3437.5)
    assert math.isclose(r['netRevenue'],65312.5)
    assert math.isclose(r['contributionAfterAcquisition'],6812.5)
    assert math.isclose(r['mediaCostPerOrder'],48)
    assert math.isclose(r['allInCostPerOrder'],50.4)
    # Thresholds hold one other configuration fixed; no statistical validity is implied.
    assert abs(calculate(dict(a,cvr=r['breakEvenCvr']))['contributionAfterAcquisition'])<1e-8
    assert abs(calculate(dict(a,cpc=r['breakEvenCpc']))['contributionAfterAcquisition'])<1e-8
    assert calculate(dict(a,cvr=0))['mediaCostPerOrder'] is None
    assert calculate(dict(a,cvr=0))['contributionAfterAcquisition']==-21000
    z=calculate(dict(a,budget=0,fixed=250));assert z['netRoas'] is None and z['allInCostPerOrder'] is None and z['contributionAfterAcquisition']==-250
    loss=calculate(dict(a,price=20));assert loss['valid'] and loss['contributionAfterAcquisition']<0 and loss['breakEvenCvr'] is None
    assert not calculate(dict(a,cpc=0))['valid']
    assert not calculate(dict(a,ctr=0))['valid']
    assert not calculate(dict(a,cvr=1.1))['valid']
    assert not calculate(dict(a,refund=1.1))['valid']
    assert not calculate(dict(a,price=None))['valid']
    assert not calculate(dict(a,budget=-1))['valid']
    assert not calculate(dict(a,budget=1e308,cpc=.01))['valid']
    assert calculate(dict(a,refund=.1))['contributionAfterAcquisition']<r['contributionAfterAcquisition']
    assert calculate(dict(a,fixed=a['fixed']+500))['contributionAfterAcquisition']==r['contributionAfterAcquisition']-500
    other_ctr=calculate(dict(a,ctr=.03));assert other_ctr['contributionAfterAcquisition']==r['contributionAfterAcquisition'] and other_ctr['impressions']!=r['impressions']
    fc=next(x for x in sensitivity(a,config['fields']) if x['key']=='fc');assert fc['minus']>fc['plus']
    high=calculate(dict(a,cpc=200));assert high['breakEvenCvr']>1 and not high['breakEvenCvrFeasible']
    invalid=stress(dict(a,cvr=.9),config['stressCases'][2]);assert not invalid['result']['valid']
    # Refunds are counted once: cost bridge and unit formulation must agree.
    bridge=r['bookedRevenue']-r['refundAllowance']-r['variableCost']-a['budget']-a['fixed']
    assert math.isclose(bridge,r['contributionAfterAcquisition'])

def reproduce(path):
    config=json.loads(Path(path).read_text());verify(config)
    a=config['default']
    return {'version':2,'status':'Constructed scenario outputs; no observed business results or approved targets.','default':calculate(a),'presets':{k:calculate(p['inputs']) for k,p in config['presets'].items()},'stressCases':[stress(a,s) for s in config['stressCases']],'sensitivity':sensitivity(a,config['fields']),'verification':'Policy, arithmetic and boundary assertions passed; no assumptions empirically validated.'}

if __name__=='__main__':
    path=sys.argv[1] if len(sys.argv)>1 else Path(__file__).with_name('commercial_model_inputs.json')
    print(json.dumps(reproduce(path),ensure_ascii=False,indent=2,allow_nan=False))
