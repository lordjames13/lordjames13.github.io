"""Reproduce GearLab's independent keyboard and headset GTM case calculations.

Python 3 standard library only. No sales or customer observations are included.
Run from any directory: python3 /path/to/reproduce_gtm_cases.py
Outputs are written beside this script. Inputs and limitations travel with them.
"""
from pathlib import Path
import csv
import json
import math

ROOT = Path(__file__).resolve().parent


def calculate(inputs):
    price = inputs["assumed_unit_revenue_usd"]
    clicks = inputs["assumed_ad_clicks"]
    cpc = inputs["assumed_cpc_usd"]
    rows = []
    for margin in inputs["assumed_pre_ad_contribution_margins"]:
        for cvr in inputs["assumed_orders_per_ad_click"]:
            spend = clicks * cpc
            orders = clicks * cvr
            revenue = orders * price
            contribution = revenue * margin - spend
            rows.append(dict(
                evidence_type="hypothetical_scenario_not_observed", clicks=clicks,
                unit_revenue_usd=price, cpc_usd=cpc, contribution_margin=margin,
                ad_click_conversion=cvr, modeled_orders=orders,
                ad_spend_usd=spend, ad_attributed_revenue_usd=revenue,
                contribution_after_ads_proxy_usd=contribution,
                acos=spend / revenue, roas=revenue / spend,
                break_even_acos=margin, break_even_roas=1 / margin,
                break_even_cpc_usd=price * margin * cvr,
                break_even_ad_click_conversion=cpc / (price * margin)))
    widths = inputs["manufacturer_keyboard_width_mm"]
    delta = widths["Wooting 80HE+"] - widths["ROG Falchion Ace 75 HE"]
    summary = dict(
        evidence_boundary=inputs["evidence_boundary"],
        keyboard_width_difference_mm=round(delta, 2),
        keyboard_relative_width_reduction_percent=100 * delta / widths["Wooting 80HE+"],
        width_interpretation="Published product width only; not measured desk space or player performance.",
        scenario_count=len(rows), inputs=inputs)
    # Arithmetic checks protect meaningful identities and the key decision example.
    for r in rows:
        assert math.isclose(r["acos"] * r["roas"], 1)
        assert math.isclose(r["break_even_cpc_usd"] * clicks,
                            r["ad_attributed_revenue_usd"] * r["contribution_margin"])
    example = [r for r in rows if r["ad_click_conversion"] == .02]
    assert example[0]["contribution_after_ads_proxy_usd"] == -2000
    assert example[1]["contribution_after_ads_proxy_usd"] == 2000
    assert round(delta, 2) == 26.34
    return rows, summary


if __name__ == "__main__":
    inputs = json.loads((ROOT / "gtm_case_inputs.json").read_text())
    rows, summary = calculate(inputs)
    with (ROOT / "gtm_scenarios.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0], lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    (ROOT / "gtm_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"Reproduced {len(rows)} hypothetical scenarios; width difference {summary['keyboard_width_difference_mm']:.2f} mm. Arithmetic checks passed.")
