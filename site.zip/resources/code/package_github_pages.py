"""Package only reviewed public static files for the free GitHub Pages site."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,zipfile,datetime
ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
target=Path(args.output).resolve();target.parent.mkdir(parents=True,exist_ok=True)
assert not target.is_relative_to(ROOT/'dist') and not target.is_relative_to(ROOT/'resources'),'Archive must be outside the public output and resources.'
for name in ['build_public_resume.py','build_evidence_snapshot.py','build_evidence_release.py']:
 subprocess.run([sys.executable,str(ROOT/'resources/code'/name)],cwd=ROOT,check=True)
subprocess.run(['node','resources/code/check_evidence_release.js'],cwd=ROOT,check=True)
subprocess.run([sys.executable,str(ROOT/'resources/code/build_public_site.py')],cwd=ROOT,check=True)
out=ROOT/'dist';(out/'.nojekyll').write_text('')
files=[p for p in sorted(out.rglob('*')) if p.is_file()]
assert not any(p.name=='Juewen_Chen_Product_GTM_Resume.pdf' for p in files)
assert not any(p.name.startswith('.env') or '.git' in p.relative_to(out).parts for p in files)
manifest={'release_id':'2026-11-15-github-pages','site_url':'https://lordjames13.github.io/','built_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}}
(out/'public_release.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(out).as_posix())
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert 'index.html' in z.namelist() and 'public_release.json' in z.namelist()
print('Ready:',target,'bytes:',target.stat().st_size,'files:',len(manifest['files'])+1)
