#!/usr/bin/env python3
"""Exercise the proposed reporting query against synthetic in-memory rows, not company data."""
import sqlite3
from pathlib import Path

schema='''CREATE TABLE campaign_day_sku(
report_date TEXT,marketplace TEXT,currency TEXT,sku TEXT,campaign TEXT,
attribution_window_days INTEGER,attribution_basis TEXT,sales_scope TEXT,
sales_basis TEXT,date_basis TEXT,report_timezone TEXT,allocation_version TEXT,
attribution_mature BOOLEAN,returns_mature BOOLEAN,
ad_spend_usd REAL,ad_clicks INTEGER,ad_attributed_orders REAL,
ad_attributed_net_sales_usd REAL,attributed_variable_cost_usd REAL,allocated_fixed_cost_usd REAL)'''
base=['2026-01-01','US','USD','example','ready',14,'click','promoted_only','net_refund_adjusted','click_date','UTC','v1',True,True,100,100,2,300,120,30]
rows=[]
def add(name,changes=None):
    r=base.copy();r[4]=name
    for index,value in (changes or {}).items():r[index]=value
    rows.append(r)
add('ready')
add('missing_cost',{18:None})
add('immature_returns',{13:False})
add('duplicates');add('duplicates')
add('version_clash');add('version_clash',{11:'v2'})
add('blank_timezone',{10:'  '})
add('wrong_sales_basis',{8:'gross_booked'})
add('zero_orders_costs',{16:0,17:0,18:10,19:0})
add('no_spend',{14:0,15:0,16:0,17:0,18:0,19:25})
# A single bad row must block an otherwise complete group, not vanish from WHERE.
add('partial_group');add('partial_group',{0:'2026-01-02',18:None})
con=sqlite3.connect(':memory:');con.row_factory=sqlite3.Row;con.execute(schema)
con.executemany('INSERT INTO campaign_day_sku VALUES ('+','.join('?'*20)+')',rows)
query=Path(__file__).with_name('gtm_campaign_review.sql').read_text()
result={r['campaign']:dict(r) for r in con.execute(query)}
r=result['ready'];assert r['evidence_status']=='READY_ATTRIBUTED_PROXY'
assert r['attributed_contribution_after_media_and_allocated_fixed_proxy_usd']==50
assert r['attributed_net_roas']==3 and r['media_cost_per_attributed_order_usd']==50
for name in ['missing_cost','immature_returns','duplicates','wrong_sales_basis','partial_group','version_clash','blank_timezone']:
    assert result[name]['evidence_status']=='WITHHELD_RECONCILE_INPUTS'
    assert result[name]['attributed_contribution_after_media_and_allocated_fixed_proxy_usd'] is None
    assert result[name]['ad_spend_usd'] is None
assert result['duplicates']['duplicate_rows']==2
assert result['partial_group']['ready_row_share']==.5
r=result['zero_orders_costs'];assert r['attributed_contribution_after_media_and_allocated_fixed_proxy_usd']==-110
assert r['media_cost_per_attributed_order_usd'] is None
assert result['no_spend']['attributed_net_roas'] is None
assert result['no_spend']['attributed_contribution_after_media_and_allocated_fixed_proxy_usd']==-25
print('PASS: synthetic SQL fixtures retain losses and zero-sales costs; undefined ratios are NULL; missing cost, immature returns, duplicate grains, wrong sales basis and partially ready groups withhold outputs.')
