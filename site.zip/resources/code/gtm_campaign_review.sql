-- Proposed reporting template v2. Executable against synthetic fixtures only.
-- Input: finance-reviewed campaign_day_sku, one row per report_date x marketplace
-- x currency x SKU x campaign x attribution/window/date/sales scope below.
-- Pre-aggregate each source BEFORE linking it. This query performs no raw-order
-- join and does not allocate shared spend or setup cost. Upstream must allocate
-- each expense once, document the version, and prevent overlapping channel credit.
-- Required columns and full interpretation are in Commercial Standard 16.
-- Net sales are refund-adjusted, excluding tax; variable cost excludes the refund
-- principal already removed from sales. Returned inventory recovery is netted in
-- product cost. Zero-sales cohorts may still have costs and must remain visible.
-- A missing/immature/duplicate/unsupported row withholds the whole group; it is
-- never silently dropped to improve reported economics. Counts are diagnostics.
-- Outputs are attributed order economics, NOT incremental profit or true CAC.
WITH grain_checked AS (
  SELECT *, COUNT(*) OVER (
    PARTITION BY report_date, marketplace, currency, sku, campaign,
                 attribution_window_days, attribution_basis, sales_scope,
                 sales_basis, date_basis, report_timezone
  ) AS grain_count
  FROM campaign_day_sku
), checked AS (
  SELECT *, CASE WHEN
      grain_count = 1
      AND attribution_mature = TRUE AND returns_mature = TRUE
      AND currency = 'USD' AND sales_basis = 'net_refund_adjusted'
      AND sales_scope = 'promoted_only' AND attribution_basis = 'click'
      AND attribution_window_days > 0
      AND report_date IS NOT NULL AND TRIM(CAST(report_date AS TEXT)) <> ''
      AND marketplace IS NOT NULL AND TRIM(marketplace) <> ''
      AND sku IS NOT NULL AND TRIM(sku) <> ''
      AND campaign IS NOT NULL AND TRIM(campaign) <> ''
      AND date_basis IN ('click_date', 'conversion_date')
      AND report_timezone IS NOT NULL AND TRIM(report_timezone) <> ''
      AND allocation_version IS NOT NULL AND TRIM(allocation_version) <> ''
      AND ad_spend_usd IS NOT NULL AND ad_spend_usd >= 0
      AND ad_clicks IS NOT NULL AND ad_clicks >= 0
      AND ad_attributed_orders IS NOT NULL AND ad_attributed_orders >= 0
      AND ad_attributed_net_sales_usd IS NOT NULL AND ad_attributed_net_sales_usd >= 0
      AND attributed_variable_cost_usd IS NOT NULL AND attributed_variable_cost_usd >= 0
      AND allocated_fixed_cost_usd IS NOT NULL AND allocated_fixed_cost_usd >= 0
    THEN 1 ELSE 0 END AS row_ready
  FROM grain_checked
), grouped AS (
  SELECT marketplace, currency, sku, campaign, attribution_window_days,
         attribution_basis, sales_scope, sales_basis, date_basis,
         report_timezone, allocation_version,
         COUNT(*) AS input_rows,
         SUM(row_ready) AS ready_rows,
         SUM(CASE WHEN grain_count > 1 THEN 1 ELSE 0 END) AS duplicate_rows,
         SUM(CASE WHEN attribution_mature = TRUE AND returns_mature = TRUE THEN 1 ELSE 0 END) AS mature_rows,
         MIN(row_ready) AS all_rows_ready,
         SUM(ad_spend_usd) AS spend,
         SUM(ad_clicks) AS clicks,
         SUM(ad_attributed_orders) AS orders,
         SUM(ad_attributed_net_sales_usd) AS net_sales,
         SUM(attributed_variable_cost_usd) AS variable_cost,
         SUM(allocated_fixed_cost_usd) AS fixed_cost
  FROM checked
  GROUP BY marketplace, currency, sku, campaign, attribution_window_days,
           attribution_basis, sales_scope, sales_basis, date_basis,
           report_timezone, allocation_version
)
SELECT marketplace, currency, sku, campaign, attribution_window_days,
       attribution_basis, sales_scope, sales_basis, date_basis,
       report_timezone, allocation_version,
       input_rows, ready_rows, duplicate_rows, mature_rows,
       CAST(ready_rows AS REAL) / NULLIF(input_rows, 0) AS ready_row_share,
       CASE WHEN all_rows_ready = 1 THEN 'READY_ATTRIBUTED_PROXY'
            ELSE 'WITHHELD_RECONCILE_INPUTS' END AS evidence_status,
       CASE WHEN all_rows_ready = 1 THEN spend END AS ad_spend_usd,
       CASE WHEN all_rows_ready = 1 THEN clicks END AS ad_clicks,
       CASE WHEN all_rows_ready = 1 THEN orders END AS ad_attributed_orders,
       CASE WHEN all_rows_ready = 1 THEN net_sales END AS ad_attributed_net_sales_usd,
       CASE WHEN all_rows_ready = 1 THEN CAST(orders AS REAL) / NULLIF(clicks, 0) END AS orders_per_ad_click,
       CASE WHEN all_rows_ready = 1 THEN spend / NULLIF(orders, 0) END AS media_cost_per_attributed_order_usd,
       CASE WHEN all_rows_ready = 1 THEN net_sales / NULLIF(spend, 0) END AS attributed_net_roas,
       CASE WHEN all_rows_ready = 1 THEN spend / NULLIF(net_sales, 0) END AS attributed_net_acos,
       CASE WHEN all_rows_ready = 1 THEN net_sales - variable_cost - spend - fixed_cost END
           AS attributed_contribution_after_media_and_allocated_fixed_proxy_usd
FROM grouped;
