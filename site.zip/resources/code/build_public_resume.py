"""Build a public résumé with the GearLab project; original private résumé is retained."""
from pathlib import Path
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
ROOT=Path(__file__).resolve().parents[2]
for name,file in [('Body','DejaVuSerif.ttf'),('Bold','DejaVuSerif-Bold.ttf')]:
 pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Body',boldItalic='Bold')
style=ParagraphStyle('body',fontName='Body',fontSize=8.1,leading=10.5,textColor=colors.HexColor('#1b2938'),spaceAfter=2)
heading=ParagraphStyle('heading',parent=style,fontName='Bold',fontSize=9.3,leading=13,spaceBefore=5,spaceAfter=3,textColor=colors.HexColor('#203f5c'))
center=ParagraphStyle('center',parent=style,alignment=TA_CENTER,fontSize=8.3,leading=12)
story=[]
def para(text,sty=style):story.append(Paragraph(text,sty))
def section(t):para(t,heading)
def bullet(t):para('• '+t)
def job(org,role,location,date):
 para('<b>'+org+'</b> — '+location)
 para(role+' | '+date)
para('JUEWEN CHEN',ParagraphStyle('name',parent=center,fontName='Bold',fontSize=20,leading=25,spaceAfter=5))
para('PRODUCT MARKETING | GO-TO-MARKET | PRODUCT &amp; DATA ANALYTICS',center)
para('New York, NY | Open to relocation | jc6691@cumc.columbia.edu',center)
para('<link href="https://lordjames13.github.io/">lordjames13.github.io</link>',center)
section('PROFILE')
para('Quantitative researcher and consumer-electronics enthusiast with product requirements, prototype validation, audience-facing communication and SQL/Python analytics experience. Personally uses gaming keyboards and mice; separates personal observations from published evidence.')
section('INDEPENDENT PROJECT')
job('GearLab Product Insights','Product Research &amp; Analytics Portfolio — AI-assisted','Independent','2026–Present')
bullet('Built a searchable 417-model discovery index and 41 descriptive Compare records; added field-specific source checks, exact-edition limitations and separate evidence states instead of implying every indexed model was tested.')
bullet('Developed reproducible Python/JavaScript preference and commercial scenario models; documented assumptions, missing data, sensitivity checks and unresolved engineering or market hypotheses.')
bullet('Added an AI-operated website evidence-retrieval task audit with raw failures, fixes and a repeat run. Published manuscripts and code; no firsthand hardware-performance study is claimed.')
section('RELEVANT EXPERIENCE')
job('PHASE Scientific','Global Data Science Intern','Remote','Oct 2026–Present')
bullet('Translated three analyst tasks into seven requirements, user stories and acceptance criteria for a synthetic-data QC MVP; wrote a PRD and built an offline HTML prototype with sample lookup, filters and explainable exclusions.')
bullet('Validated 10 prototype-logic and 18 data-quality checks; incorporated supervisor feedback into validation rules, configurable parameters and reproducible handoff instructions.')
bullet('Analyzed 500 synthetic specimen records in SQL/Python and reconciled 163 QC, diagnostic-performance and site/batch timing metrics; summarized results in a report and Excel dashboard.')
job('The Crow HEAL Project','Public Health Strategy &amp; Research Intern','Brooklyn, NY','Jun–Aug 2026')
bullet('Mapped five proposed AI health-coach capabilities to stakeholder evidence needs and privacy priorities; prioritized a resource-navigation MVP using a value–feasibility–safety matrix, with scope, user stories and privacy trade-offs.')
bullet('Analyzed 600 fictional users and 7,250 simulated events to define onboarding, activation, cohort and retention metrics; documented interpretation limits.')
job('Harlem Wellness Center — AFC Awareness Project','Public Health Research Intern','New York, NY','Jul–Sep 2026')
bullet('Supported social media, newsletter, flyer and brand-collaboration promotion; translated 12 research and policy sources into audience-facing materials and reviewed content for compliance.')
bullet('Contacted eight community organizations and secured support from all eight, coordinating outreach around patient choice and healthcare access.')
job('High Assurance and Secure Systems (HASS) Research Center','Research Assistant','Lawrence, KS (Remote)','Jun 2024–Aug 2025')
bullet('Automated Python benchmarking of GPT-4o and Tencent Yuanbao across 3,000+ labelled images, structuring JSON outputs to examine accuracy, confidence and explanations.')
bullet('Compared five GPT-4o prompt strategies; best accuracy reached 85.00% versus an 80.42% zero-shot baseline, with error patterns and refusals documented in an unpublished manuscript.')
section('EDUCATION')
para('<b>Columbia University</b> | M.S. Epidemiology | Expected May 2027')
para('<b>Xi’an Jiaotong-Liverpool University</b> | B.S. Financial Mathematics | May 2025')
section('SKILLS')
para('<b>Product &amp; GTM:</b> PRDs, user stories, acceptance criteria, MVP prioritization, comparative research, product measurement, audience-facing content')
para('<b>Data &amp; AI:</b> Excel (VBA), SQL (SQLite), Python, Power BI, Tableau, Claude Code, Cursor, model benchmarking')
para('<b>Marketing &amp; Communication:</b> Social content, newsletters, outreach/partnerships, content compliance, PowerPoint, stakeholder communication')
SimpleDocTemplate(str(ROOT/'resources/resume/Juewen_Chen_GearLab_Public_Resume.pdf'),pagesize=(612,792),rightMargin=38,leftMargin=38,topMargin=30,bottomMargin=28,title='Juewen Chen — Product Research and GTM',author='Juewen Chen').build(story)
print('Built public résumé.')
