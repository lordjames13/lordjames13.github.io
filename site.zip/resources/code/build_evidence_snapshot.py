from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[2]
data=json.loads((ROOT/'resources/code/product_evidence_registry.json').read_text())
(ROOT/'assets/js/evidence_data.js').write_text('/* Generated from resources/code/product_evidence_registry.json. */\nvar GL_EVIDENCE = '+json.dumps(data,ensure_ascii=False,indent=2)+';\n')
print('Updated evidence browser snapshot.')
