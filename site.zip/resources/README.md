# GearLab — Research, Code and Validation

Release: 2026-11-14-evidence-closure. Maintainer: Juewen Chen.

This independent, AI-assisted portfolio distinguishes indexed models, descriptive Compare entries, selected-field source checks, linked external tests and published firsthand hardware tests. Zero firsthand hardware-test records are published in this release. Software task validation is a separate category; one AI operator is not a human usability sample. Scenario economics are hypothetical.

## Inspect

`resources/release_registry.json` indexes every numbered manuscript and downloadable code/raw record with its SHA-256. Article 17 preserves the predefined protocol, baseline failures, fixes and repeat observations. `resources/code/product_evidence_registry.json` defines evidence states and checked fields. Missing fields and ambiguous variants are retained as unknown, not imputed or ranked.

## Reproduce from the repository or extracted pack root

```bash
node resources/code/check_evidence_release.js
node resources/code/check_comparator_parity.js
node resources/code/check_commercial_model.js
python resources/code/check_commercial_reporting.py
python resources/code/GearLab_Comparator_Reproducibility.py
python resources/code/reproduce_business_cases.py
```

Python model checks use the standard library. Node checks require Node.js. The public résumé generator additionally needs ReportLab and DejaVu fonts. Snapshot generation is a maintainer action; it does not retrieve fresh product facts.

## Make a future change

1. Update exact model/region, source URL, named checked fields, date and limitations in the canonical evidence registry. Do not infer a product-wide verification badge from one linked field. Add an external test only with publisher/method and exact-model scope. Firsthand status requires a real device/protocol/raw-result record.
2. Run `python resources/code/build_evidence_snapshot.py`; card data in `assets/js/gearlab_0.js` and catalog aliases must agree with registry identities. Article titles come from their first Markdown heading; old route slugs remain stable.
3. Update completed work versus proposed work explicitly. Preserve original task failures; do not overwrite a protocol to change its criteria after a run.
4. Run the checks above. Run `python resources/code/build_evidence_release.py` to regenerate the directory, registry, standalone ZIP and integrity inventory; run the evidence check again. Verify static local links and visible routes.
5. Deploy a reviewed public static build that excludes the original private résumé and development files. Keep the source repository private. Check the root, evidence page, public résumé, registry and ZIP with an HTTP client that sends no cookies or authorization. Verify PDF/ZIP signatures, not only status codes. Record the deployment version separately from source content hashes.

The public résumé omits the phone number and includes the GearLab project. The original résumé remains in the private source repository and must not be copied to the public build. The ZIP contains public research, code and raw website observations only; no résumé or private repository history.
